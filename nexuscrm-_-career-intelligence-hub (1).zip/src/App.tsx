/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { getApiUrl, apiFetch } from './lib/api';
import { 
  Home, 
  User, 
  Cpu, 
  GraduationCap, 
  Award, 
  Briefcase, 
  Laptop, 
  Rocket, 
  FileText, 
  Link2, 
  GitBranch, 
  Users, 
  Star, 
  MessageSquare, 
  FolderLock, 
  Globe, 
  Settings, 
  LogOut, 
  Plus, 
  X, 
  Menu, 
  UserPlus, 
  CheckCircle2, 
  Wifi,
  Sparkles,
  StickyNote,
  Calendar,
  AlertTriangle
} from 'lucide-react';

import { 
  PersonalProfile, 
  Skill, 
  Education, 
  Certification, 
  Experience, 
  CurrentJob, 
  Project, 
  PortfolioLink, 
  TimelineMilestone, 
  Contact, 
  Achievement, 
  Testimonial, 
  VaultDocument,
  CalendarEvent,
  NotepadNote,
  ResumeItem,
  EMPTY_PROFILE,
  EMPTY_CURRENT_JOB,
  INITIAL_PROFILE, 
  INITIAL_SKILLS, 
  INITIAL_EDUCATION, 
  INITIAL_CERTIFICATIONS, 
  INITIAL_EXPERIENCE, 
  INITIAL_CURRENT_JOB, 
  INITIAL_PROJECTS, 
  INITIAL_LINKS, 
  INITIAL_TIMELINE, 
  INITIAL_CONTACTS, 
  INITIAL_ACHIEVEMENTS, 
  INITIAL_TESTIMONIALS, 
  INITIAL_DOCUMENTS,
  INITIAL_CALENDAR_EVENTS,
  decodePortfolioData,
  encodePortfolioData
} from './types';

// Tab Components
import OverviewTab from './components/OverviewTab';
import ProfileTab from './components/ProfileTab';
import SkillsTab from './components/SkillsTab';
import EducationTab from './components/EducationTab';
import CertificationsTab from './components/CertificationsTab';
import ExperienceTab from './components/ExperienceTab';
import CurrentJobTab from './components/CurrentJobTab';
import ProjectsTab from './components/ProjectsTab';
import ResumeTab from './components/ResumeTab';
import PortfoliosTab from './components/PortfoliosTab';
import TimelineTab from './components/TimelineTab';
import ContactsTab from './components/ContactsTab';
import AchievementsTab from './components/AchievementsTab';
import TestimonialsTab from './components/TestimonialsTab';
import DocumentVaultTab from './components/DocumentVaultTab';
import SettingsTab from './components/SettingsTab';
import NotepadTab from './components/NotepadTab';
import CalendarTab from './components/CalendarTab';
import PublicPortfolioView from './components/PublicPortfolioView';
import AuthPage from './components/AuthPage';
import { heavyStorage } from './lib/heavyStorage';
import { handleOAuthCallback } from './lib/googleDrive';


export default function App() {
  
  // Helper to merge array records by ID or unique key without dropping any records
  const mergeArrayRecords = <T extends { id?: string; name?: string }>(incoming?: T[], existing?: T[]): T[] => {
    const inc = Array.isArray(incoming) ? incoming : [];
    const ext = Array.isArray(existing) ? existing : [];
    if (inc.length === 0) return ext;
    if (ext.length === 0) return inc;

    const map = new Map<string, T>();
    // First keep existing records
    for (const item of ext) {
      const key = item.id || (item.name ? item.name.toLowerCase().trim() : `item_${Math.random()}`);
      map.set(key, item);
    }
    // Then merge/update incoming records
    for (const item of inc) {
      const key = item.id || (item.name ? item.name.toLowerCase().trim() : `item_${Math.random()}`);
      map.set(key, item);
    }
    return Array.from(map.values());
  };

  // Helper to retrieve the current active user's standardized email address
  const getCurrentUserEmail = (): string | null => {
    const saved = localStorage.getItem('nexus_current_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed?.email?.toLowerCase()?.trim() || null;
      } catch (e) {}
    }
    return null;
  };

  const lastLoadedEmailRef = useRef<string | null>(getCurrentUserEmail());
  const isDocsRestoringRef = useRef<boolean>(true);
  const isCertsRestoringRef = useRef<boolean>(true);
  const isProjsRestoringRef = useRef<boolean>(true);

  // Enforce clean slate ONCE initially to secure empty-by-default behavior
  if (!localStorage.getItem('nexus_empty_slate_initialized_v2')) {
    localStorage.removeItem('nexus_profile');
    localStorage.removeItem('nexus_skills');
    localStorage.removeItem('nexus_education');
    localStorage.removeItem('nexus_certs');
    localStorage.removeItem('nexus_experience');
    localStorage.removeItem('nexus_current_job');
    localStorage.removeItem('nexus_projects');
    localStorage.removeItem('nexus_links');
    localStorage.removeItem('nexus_milestones');
    localStorage.removeItem('nexus_contacts');
    localStorage.removeItem('nexus_achievements');
    localStorage.removeItem('nexus_testimonials');
    localStorage.removeItem('nexus_documents');
    localStorage.setItem('nexus_empty_slate_initialized_v2', 'true');
  }

  // State hooks for public asynchronous share view database and loader status
  const [remoteShareData, setRemoteShareData] = useState<{
    profile: PersonalProfile;
    skills: Skill[];
    experience: Experience[];
    certifications: Certification[];
    projects: Project[];
    education: Education[];
    achievements: Achievement[];
    testimonials: Testimonial[];
    links: PortfolioLink[];
  } | null>(null);
  const [loadingRemoteShare, setLoadingRemoteShare] = useState<boolean>(true);

  // 1. Unified State Initializer
  const [profile, setProfile] = useState<PersonalProfile>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_profile`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          return { ...EMPTY_PROFILE, ...parsed };
        } catch (e) {}
      }
      
      // Intelligent fallback for new accounts to use their signup identification
      const userJSON = localStorage.getItem('nexus_current_user');
      if (userJSON) {
        try {
          const parsedUser = JSON.parse(userJSON);
          if (parsedUser && parsedUser.email?.toLowerCase().trim() === email) {
            return {
              ...EMPTY_PROFILE,
              email: email,
              firstName: parsedUser.firstName || "",
              lastName: parsedUser.lastName || "",
              name: `${parsedUser.firstName || ""} ${parsedUser.lastName || ""}`.trim(),
              headline: "",
            };
          }
        } catch (e) {}
      }
    }
    return EMPTY_PROFILE;
  });

  const [skills, setSkills] = useState<Skill[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_skills`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Skill[] = [];
            const seen = new Set<string>();
            for (const s of parsed) {
              if (s && s.name) {
                const nameLower = s.name.toLowerCase().trim();
                if (!seen.has(nameLower)) {
                  seen.add(nameLower);
                  unique.push(s);
                }
              }
            }
            return unique.map((s: any) => {
              if (!s.visibility) {
                return {
                  id: s.id,
                  name: s.name,
                  visibility: 'public',
                  yearsOfExp: s.yearsOfExp || 1,
                  endorsements: s.endorsements || 0
                };
              }
              return s;
            });
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [education, setEducation] = useState<Education[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_education`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Education[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = `${item.institution || ''}-${item.degree || ''}`.toLowerCase().trim();
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [certifications, setCertifications] = useState<Certification[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_certs`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Certification[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = (item.title || '').toLowerCase().trim();
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [experience, setExperience] = useState<Experience[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_experience`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Experience[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = `${item.role || ''}-${item.company || ''}`.toLowerCase().trim();
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [currentJob, setCurrentJob] = useState<CurrentJob>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_current_job`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed) {
            return { ...EMPTY_CURRENT_JOB, ...parsed };
          }
        } catch (e) {}
      }
    }
    return EMPTY_CURRENT_JOB;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_projects`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Project[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = item.id || (item.name ? `${item.name.toLowerCase().trim()}_${item.date || ''}` : `proj_${Math.random()}`);
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [products, setProducts] = useState<Project[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_products`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Project[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = item.id || (item.name ? `${item.name.toLowerCase().trim()}_${item.date || ''}` : `prod_${Math.random()}`);
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [others, setOthers] = useState<Project[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_others`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const unique: Project[] = [];
            const seen = new Set<string>();
            for (const item of parsed) {
              const key = item.id || (item.name ? `${item.name.toLowerCase().trim()}_${item.date || ''}` : `oth_${Math.random()}`);
              if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
              }
            }
            return unique;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [links, setLinks] = useState<PortfolioLink[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_links`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [resumeLinks, setResumeLinks] = useState<PortfolioLink[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_resume_links`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [milestones, setMilestones] = useState<TimelineMilestone[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_milestones`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [contacts, setContacts] = useState<Contact[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_contacts`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_achievements`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_testimonials`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [documents, setDocuments] = useState<VaultDocument[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_documents`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return [];
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_calendar_events`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (e) {}
      }
    }
    return INITIAL_CALENDAR_EVENTS;
  });

  const [notes, setNotes] = useState<NotepadNote[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_notepad_notes`);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {}
      }
    }
    return [];
  });

  const [resumes, setResumes] = useState<ResumeItem[]>(() => {
    const email = getCurrentUserEmail();
    if (email) {
      const saved = localStorage.getItem(`${email}_nexus_vault_resumes`);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {}
      }
    }
    return [];
  });

  // Active navigation sidebar link
  const [activeTab, setActiveTab] = useState<string>('overview');
  
  // Mobile drawer state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Current logged in user state
  const [currentUser, setCurrentUser] = useState<{ email: string; firstName?: string; lastName?: string } | null>(() => {
    const saved = localStorage.getItem('nexus_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  // Styled custom modal dialog to bypass native iframe confirm blocking
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Margin notification toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

   const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Check for the Google Drive OAuth redirect hash and set activeTab
  useEffect(() => {
    if (window.location.hash && window.location.hash.includes('access_token')) {
      try {
        const parsed = handleOAuthCallback();
        if (parsed?.token) {
          setActiveTab('vault');
          triggerToast("🔑 Google Drive connected successfully! Upload and download are now active.");
        }
      } catch (e) {
        console.error("OAuth callback handling failed:", e);
      }
    }
  }, []);

  const safeLocalStorageSetItem = (key: string, value: string) => {
    // 1. Save to high-capacity IndexedDB database first to guarantee permanent persistence
    try {
      const parsed = JSON.parse(value);
      heavyStorage.set(key, parsed).catch(dbErr => {
        console.error(`IndexedDB background put failed for key "${key}":`, dbErr);
      });
    } catch (_) {
      heavyStorage.set(key, value).catch(dbErr => {
        console.error(`IndexedDB background raw put failed for key "${key}":`, dbErr);
      });
    }

    // 2. High-capacity safeguard: if value is large (> 250KB), keep exclusively in IndexedDB to avoid filling 5MB localStorage quota
    if (value.length > 250000) {
      return;
    }

    // 3. Save small configuration items to localStorage with graceful fallback
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      if (error instanceof DOMException && (
        error.name === 'QuotaExceededError' ||
        error.name === 'NS_ERROR_DOM_QUOTA_REACHED'
      )) {
        // Silently clear any legacy pending sync strings from localStorage to free space
        try {
          for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith('nexus_pending_sync_')) {
              localStorage.removeItem(k);
            }
          }
        } catch (_) {}
      }
    }
  };

  // Sync currentUser with localStorage
  useEffect(() => {
    if (currentUser) {
      safeLocalStorageSetItem('nexus_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('nexus_current_user');
    }
  }, [currentUser]);

  // 2. State persistence side-effects
  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_profile`, JSON.stringify(profile));
      }
    }
  }, [profile, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_skills`, JSON.stringify(skills));
      }
    }
  }, [skills, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_education`, JSON.stringify(education));
      }
    }
  }, [education, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        if (isCertsRestoringRef.current) {
          return;
        }
        safeLocalStorageSetItem(`${email}_certs`, JSON.stringify(certifications));
      }
    }
  }, [certifications, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_experience`, JSON.stringify(experience));
      }
    }
  }, [experience, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_current_job`, JSON.stringify(currentJob));
      }
    }
  }, [currentJob, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        if (isProjsRestoringRef.current) {
          return;
        }
        safeLocalStorageSetItem(`${email}_projects`, JSON.stringify(projects));
      }
    }
  }, [projects, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        if (isProjsRestoringRef.current) {
          return;
        }
        safeLocalStorageSetItem(`${email}_products`, JSON.stringify(products));
      }
    }
  }, [products, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        if (isProjsRestoringRef.current) {
          return;
        }
        safeLocalStorageSetItem(`${email}_others`, JSON.stringify(others));
      }
    }
  }, [others, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_links`, JSON.stringify(links));
      }
    }
  }, [links, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_resume_links`, JSON.stringify(resumeLinks));
      }
    }
  }, [resumeLinks, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_milestones`, JSON.stringify(milestones));
      }
    }
  }, [milestones, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_contacts`, JSON.stringify(contacts));
      }
    }
  }, [contacts, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_achievements`, JSON.stringify(achievements));
      }
    }
  }, [achievements, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_testimonials`, JSON.stringify(testimonials));
      }
    }
  }, [testimonials, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        if (isDocsRestoringRef.current) {
          return;
        }
        safeLocalStorageSetItem(`${email}_documents`, JSON.stringify(documents));
      }
    }
  }, [documents, currentUser]);

  useEffect(() => {
    if (currentUser) {
      const email = currentUser.email.toLowerCase().trim();
      if (lastLoadedEmailRef.current === email) {
        safeLocalStorageSetItem(`${email}_calendar_events`, JSON.stringify(calendarEvents));
      }
    }
  }, [calendarEvents, currentUser]);

  // Load high-capacity IndexedDB data asynchronously to bypass standard 5MB browser limits
  useEffect(() => {
    const fetchHeavyData = async () => {
      const email = currentUser?.email?.toLowerCase()?.trim() || getCurrentUserEmail();
      if (!email) {
        isDocsRestoringRef.current = false;
        isCertsRestoringRef.current = false;
        isProjsRestoringRef.current = false;
        return;
      }

      // Mark as restoring to bypass state-persistence saving the empty initial state
      isDocsRestoringRef.current = true;
      isCertsRestoringRef.current = true;
      isProjsRestoringRef.current = true;

      try {
        const dDocs = await heavyStorage.get(`${email}_documents`);
        if (dDocs && Array.isArray(dDocs) && dDocs.length > 0) {
          setDocuments(dDocs);
        }
      } catch (err) {
        console.warn("Async restoration of documents deferred:", err);
      } finally {
        isDocsRestoringRef.current = false;
      }

      try {
        const dCerts = await heavyStorage.get(`${email}_certs`);
        if (dCerts && Array.isArray(dCerts) && dCerts.length > 0) {
          setCertifications(dCerts);
        }
      } catch (err) {
        console.warn("Async restoration of certifications deferred:", err);
      } finally {
        isCertsRestoringRef.current = false;
      }

      try {
        const dProjs = await heavyStorage.get(`${email}_projects`);
        if (dProjs && Array.isArray(dProjs) && dProjs.length > 0) {
          setProjects(prev => mergeArrayRecords(dProjs, prev));
        }
      } catch (err) {
        console.warn("Async restoration of projects deferred:", err);
      }

      try {
        const dProds = await heavyStorage.get(`${email}_products`);
        if (dProds && Array.isArray(dProds) && dProds.length > 0) {
          setProducts(prev => mergeArrayRecords(dProds, prev));
        }
      } catch (err) {
        console.warn("Async restoration of products deferred:", err);
      }

      try {
        const dOthers = await heavyStorage.get(`${email}_others`);
        if (dOthers && Array.isArray(dOthers) && dOthers.length > 0) {
          setOthers(prev => mergeArrayRecords(dOthers, prev));
        }
      } catch (err) {
        console.warn("Async restoration of others deferred:", err);
      } finally {
        isProjsRestoringRef.current = false;
      }
    };

    fetchHeavyData();
  }, [currentUser]);

  const triggerSaveAll = async (
    customProfile = profile,
    customSkills = skills,
    customEducation = education,
    customCertifications = certifications,
    customExperience = experience,
    customCurrentJob = currentJob,
    customProjects = projects,
    customProducts = products,
    customOthers = others,
    customLinks = links,
    customResumeLinks = resumeLinks,
    customMilestones = milestones,
    customContacts = contacts,
    customAchievements = achievements,
    customTestimonials = testimonials,
    customDocuments = documents,
    customCalendarEvents = calendarEvents,
    customNotes = notes,
    customResumes = resumes
  ) => {
    if (!currentUser) return;
    const email = currentUser.email.toLowerCase().trim();

    // 1. Save to local storage immediately as offline backup
    safeLocalStorageSetItem(`${email}_profile`, JSON.stringify(customProfile));
    safeLocalStorageSetItem(`${email}_skills`, JSON.stringify(customSkills));
    safeLocalStorageSetItem(`${email}_education`, JSON.stringify(customEducation));
    safeLocalStorageSetItem(`${email}_certs`, JSON.stringify(customCertifications));
    safeLocalStorageSetItem(`${email}_experience`, JSON.stringify(customExperience));
    safeLocalStorageSetItem(`${email}_current_job`, JSON.stringify(customCurrentJob));
    safeLocalStorageSetItem(`${email}_projects`, JSON.stringify(customProjects));
    safeLocalStorageSetItem(`${email}_products`, JSON.stringify(customProducts));
    safeLocalStorageSetItem(`${email}_others`, JSON.stringify(customOthers));
    safeLocalStorageSetItem(`${email}_links`, JSON.stringify(customLinks));
    safeLocalStorageSetItem(`${email}_resume_links`, JSON.stringify(customResumeLinks));
    safeLocalStorageSetItem(`${email}_milestones`, JSON.stringify(customMilestones));
    safeLocalStorageSetItem(`${email}_contacts`, JSON.stringify(customContacts));
    safeLocalStorageSetItem(`${email}_achievements`, JSON.stringify(customAchievements));
    safeLocalStorageSetItem(`${email}_testimonials`, JSON.stringify(customTestimonials));
    safeLocalStorageSetItem(`${email}_documents`, JSON.stringify(customDocuments));
    safeLocalStorageSetItem(`${email}_calendar_events`, JSON.stringify(customCalendarEvents));
    safeLocalStorageSetItem(`${email}_notepad_notes`, JSON.stringify(customNotes));
    safeLocalStorageSetItem(`${email}_nexus_vault_resumes`, JSON.stringify(customResumes));

    const completeUserData = {
      profile: customProfile,
      skills: customSkills,
      education: customEducation,
      certifications: customCertifications,
      experience: customExperience,
      currentJob: customCurrentJob,
      projects: customProjects,
      products: customProducts,
      others: customOthers,
      links: customLinks,
      resumeLinks: customResumeLinks,
      milestones: customMilestones,
      contacts: customContacts,
      achievements: customAchievements,
      testimonials: customTestimonials,
      documents: customDocuments,
      calendarEvents: customCalendarEvents,
      notes: customNotes,
      resumes: customResumes
    };

    console.log("[PROJECT DEBUG] projects before sync:", customProjects, "COUNT:", customProjects.length);
    console.log(`[Cloud Save] Synchronizing ${customProjects.length} projects, ${customProducts.length} products, and ${customOthers.length} others for: ${email}`);

    // 2. Persist immediately to POST /api/userdata/:email
    try {
      const resp = await apiFetch(`/api/userdata/${encodeURIComponent(email)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: JSON.stringify(completeUserData) })
      });
      if (resp.ok) {
        console.log(`[Cloud Save] Data persisted successfully to server for: ${email}`);
        // Clear any pending sync for this user
        localStorage.removeItem(`nexus_pending_sync_${email}`);
        heavyStorage.remove(`nexus_pending_sync_${email}`).catch(() => {});
      } else {
        throw new Error(`HTTP Error ${resp.status}`);
      }
    } catch (e) {
      console.warn("[Cloud Save] Sync failed, queuing in background:", e);
      // Queues the offline payload in high-capacity IndexedDB to prevent QuotaExceededError
      const pendingPayload = {
        email,
        data: completeUserData,
        timestamp: Date.now()
      };
      heavyStorage.set(`nexus_pending_sync_${email}`, pendingPayload).catch(() => {});
      try {
        if (JSON.stringify(pendingPayload).length < 200000) {
          localStorage.setItem(`nexus_pending_sync_${email}`, JSON.stringify(pendingPayload));
        }
      } catch (_) {}
    }
  };

  const shouldOverwrite = (localKey: string, serverValue: any) => {
    if (serverValue === undefined || serverValue === null) return false;
    
    const localRaw = localStorage.getItem(localKey);
    if (!localRaw) return true; // Local is empty, feel free to restore from server

    try {
      const localVal = JSON.parse(localRaw);
      
      if (Array.isArray(serverValue)) {
        if (serverValue.length === 0 && Array.isArray(localVal) && localVal.length > 0) {
          return false; // Do not overwrite non-empty local array with empty server array
        }
        if (Array.isArray(localVal) && localVal.length > serverValue.length) {
          return false; // Do not overwrite larger local state with smaller server array
        }
      } else if (typeof serverValue === 'object') {
        const isServerEmpty = Object.keys(serverValue).length === 0;
        const isLocalEmpty = Object.keys(localVal).length === 0;
        if (isServerEmpty && !isLocalEmpty) {
          return false; // Do not overwrite non-empty local object with empty server object
        }
        
        if (localKey.endsWith('_profile')) {
          const serverName = serverValue.name || '';
          const localName = localVal.name || '';
          if (!serverName && localName) {
            return false; // Do not overwrite populated local profile with empty server profile
          }
        }
      }
    } catch (e) {}

    return true;
  };

  // Background sync worker effect
  useEffect(() => {
    if (!currentUser) return;
    const email = currentUser.email.toLowerCase().trim();

    const interval = setInterval(async () => {
      let pending: any = null;
      try {
        pending = await heavyStorage.get(`nexus_pending_sync_${email}`);
      } catch (_) {}

      if (!pending) {
        const pendingStr = localStorage.getItem(`nexus_pending_sync_${email}`);
        if (pendingStr) {
          try {
            pending = JSON.parse(pendingStr);
          } catch (_) {}
        }
      }

      if (!pending || !pending.data) return;

      try {
        console.log(`[Background Sync] Attempting sync retry for ${email}...`);
        const resp = await apiFetch(`/api/userdata/${encodeURIComponent(email)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: JSON.stringify(pending.data) })
        });
        if (resp.ok) {
          console.log(`[Background Sync] Success! Cleared pending sync for ${email}`);
          localStorage.removeItem(`nexus_pending_sync_${email}`);
          await heavyStorage.remove(`nexus_pending_sync_${email}`);
        }
      } catch (e) {
        console.warn("[Background Sync] Server still unreachable:", e);
      }
    }, 10000); // Retry every 10 seconds

    return () => clearInterval(interval);
  }, [currentUser]);

  const handleUserLogin = async (user: { email: string; firstName?: string; lastName?: string }) => {
    const email = user.email.toLowerCase().trim();
    
    // Save previous user, if any, and wait for it
    if (currentUser) {
      console.log(`[Login Transition] Backing up previous user ${currentUser.email}...`);
      await triggerSaveAll(
        profile,
        skills,
        education,
        certifications,
        experience,
        currentJob,
        projects,
        products,
        others,
        links,
        resumeLinks,
        milestones,
        contacts,
        achievements,
        testimonials,
        documents,
        calendarEvents,
        notes,
        resumes
      );
    }

    // Try restoring full workspace database from our REST backend
    try {
      console.log(`[Cloud Backup] Restoring workspace catalog from server for: ${email}`);
      const resp = await apiFetch(`/api/userdata/${encodeURIComponent(email)}`);
      if (resp.ok) {
        const result = await resp.json();
        if (result && result.data) {
          const payload = JSON.parse(result.data);
          if (payload) {
            if (payload.profile && shouldOverwrite(`${email}_profile`, payload.profile)) {
              localStorage.setItem(`${email}_profile`, JSON.stringify(payload.profile));
            }
            if (payload.skills && shouldOverwrite(`${email}_skills`, payload.skills)) {
              localStorage.setItem(`${email}_skills`, JSON.stringify(payload.skills));
            }
            if (payload.education && shouldOverwrite(`${email}_education`, payload.education)) {
              localStorage.setItem(`${email}_education`, JSON.stringify(payload.education));
            }
            if (payload.certifications && shouldOverwrite(`${email}_certs`, payload.certifications)) {
              localStorage.setItem(`${email}_certs`, JSON.stringify(payload.certifications));
              heavyStorage.set(`${email}_certs`, payload.certifications).catch(() => {});
            }
            if (payload.experience && shouldOverwrite(`${email}_experience`, payload.experience)) {
              localStorage.setItem(`${email}_experience`, JSON.stringify(payload.experience));
            }
            if (payload.currentJob && shouldOverwrite(`${email}_current_job`, payload.currentJob)) {
              localStorage.setItem(`${email}_current_job`, JSON.stringify(payload.currentJob));
            }
            if (payload.projects) {
              const localProjects = JSON.parse(localStorage.getItem(`${email}_projects`) || '[]');
              const merged = mergeArrayRecords(payload.projects, localProjects);
              localStorage.setItem(`${email}_projects`, JSON.stringify(merged));
              heavyStorage.set(`${email}_projects`, merged).catch(() => {});
            }
            if (payload.products) {
              const localProducts = JSON.parse(localStorage.getItem(`${email}_products`) || '[]');
              const merged = mergeArrayRecords(payload.products, localProducts);
              localStorage.setItem(`${email}_products`, JSON.stringify(merged));
              heavyStorage.set(`${email}_products`, merged).catch(() => {});
            }
            if (payload.others) {
              const localOthers = JSON.parse(localStorage.getItem(`${email}_others`) || '[]');
              const merged = mergeArrayRecords(payload.others, localOthers);
              localStorage.setItem(`${email}_others`, JSON.stringify(merged));
              heavyStorage.set(`${email}_others`, merged).catch(() => {});
            }
            if (payload.links && shouldOverwrite(`${email}_links`, payload.links)) {
              localStorage.setItem(`${email}_links`, JSON.stringify(payload.links));
              heavyStorage.set(`${email}_links`, payload.links).catch(() => {});
            }
            if (payload.resumeLinks && shouldOverwrite(`${email}_resume_links`, payload.resumeLinks)) {
              localStorage.setItem(`${email}_resume_links`, JSON.stringify(payload.resumeLinks));
              heavyStorage.set(`${email}_resume_links`, payload.resumeLinks).catch(() => {});
            }
            if (payload.milestones && shouldOverwrite(`${email}_milestones`, payload.milestones)) {
              localStorage.setItem(`${email}_milestones`, JSON.stringify(payload.milestones));
            }
            if (payload.contacts && shouldOverwrite(`${email}_contacts`, payload.contacts)) {
              localStorage.setItem(`${email}_contacts`, JSON.stringify(payload.contacts));
            }
            if (payload.achievements && shouldOverwrite(`${email}_achievements`, payload.achievements)) {
              localStorage.setItem(`${email}_achievements`, JSON.stringify(payload.achievements));
            }
            if (payload.testimonials && shouldOverwrite(`${email}_testimonials`, payload.testimonials)) {
              localStorage.setItem(`${email}_testimonials`, JSON.stringify(payload.testimonials));
            }
            if (payload.documents && shouldOverwrite(`${email}_documents`, payload.documents)) {
              localStorage.setItem(`${email}_documents`, JSON.stringify(payload.documents));
            }
            if (payload.calendarEvents && shouldOverwrite(`${email}_calendar_events`, payload.calendarEvents)) {
              localStorage.setItem(`${email}_calendar_events`, JSON.stringify(payload.calendarEvents));
            }
            if (payload.notes && shouldOverwrite(`${email}_notepad_notes`, payload.notes)) {
              localStorage.setItem(`${email}_notepad_notes`, JSON.stringify(payload.notes));
            }
            if (payload.resumes && shouldOverwrite(`${email}_nexus_vault_resumes`, payload.resumes)) {
              localStorage.setItem(`${email}_nexus_vault_resumes`, JSON.stringify(payload.resumes));
              heavyStorage.set(`${email}_nexus_vault_resumes`, payload.resumes).catch(() => {});
            }
            console.log(`[Cloud Backup] Restoration complete!`);
          }
        }
      }
    } catch (err) {
      console.warn("[Cloud Backup] Restore request bypassed or offline:", err);
    }

    // Load next user's data
    const savedProfile = localStorage.getItem(`${email}_profile`);
    if (savedProfile) {
      setProfile({ ...EMPTY_PROFILE, ...JSON.parse(savedProfile) });
    } else {
      setProfile({
        ...EMPTY_PROFILE,
        email: email,
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        name: `${user.firstName || ""} ${user.lastName || ""}`.trim(),
        headline: "",
      });
    }

    const savedSkills = localStorage.getItem(`${email}_skills`);
    setSkills(savedSkills ? JSON.parse(savedSkills) : []);

    const savedEducation = localStorage.getItem(`${email}_education`);
    setEducation(savedEducation ? JSON.parse(savedEducation) : []);

    const savedCerts = localStorage.getItem(`${email}_certs`);
    setCertifications(savedCerts ? JSON.parse(savedCerts) : []);

    const savedExperience = localStorage.getItem(`${email}_experience`);
    setExperience(savedExperience ? JSON.parse(savedExperience) : []);

    const savedCurrentJob = localStorage.getItem(`${email}_current_job`);
    setCurrentJob(savedCurrentJob ? { ...EMPTY_CURRENT_JOB, ...JSON.parse(savedCurrentJob) } : EMPTY_CURRENT_JOB);

    const savedProjects = localStorage.getItem(`${email}_projects`);
    setProjects(savedProjects ? JSON.parse(savedProjects) : []);

    const savedProducts = localStorage.getItem(`${email}_products`);
    setProducts(savedProducts ? JSON.parse(savedProducts) : []);

    const savedOthers = localStorage.getItem(`${email}_others`);
    setOthers(savedOthers ? JSON.parse(savedOthers) : []);

    const savedLinks = localStorage.getItem(`${email}_links`);
    setLinks(savedLinks ? JSON.parse(savedLinks) : []);

    const savedResumeLinks = localStorage.getItem(`${email}_resume_links`);
    setResumeLinks(savedResumeLinks ? JSON.parse(savedResumeLinks) : []);

    const savedMilestones = localStorage.getItem(`${email}_milestones`);
    setMilestones(savedMilestones ? JSON.parse(savedMilestones) : []);

    const savedContacts = localStorage.getItem(`${email}_contacts`);
    setContacts(savedContacts ? JSON.parse(savedContacts) : []);

    const savedAchievements = localStorage.getItem(`${email}_achievements`);
    setAchievements(savedAchievements ? JSON.parse(savedAchievements) : []);

    const savedTestimonials = localStorage.getItem(`${email}_testimonials`);
    setTestimonials(savedTestimonials ? JSON.parse(savedTestimonials) : []);

    const savedDocuments = localStorage.getItem(`${email}_documents`);
    setDocuments(savedDocuments ? JSON.parse(savedDocuments) : []);

    const savedCalendarEvents = localStorage.getItem(`${email}_calendar_events`);
    setCalendarEvents(savedCalendarEvents ? JSON.parse(savedCalendarEvents) : INITIAL_CALENDAR_EVENTS);

    const savedNotes = localStorage.getItem(`${email}_notepad_notes`);
    setNotes(savedNotes ? JSON.parse(savedNotes) : []);

    const savedResumes = localStorage.getItem(`${email}_nexus_vault_resumes`);
    setResumes(savedResumes ? JSON.parse(savedResumes) : []);

    lastLoadedEmailRef.current = email;
    setCurrentUser(user);
  };

  const handleUserLogout = async () => {
    if (currentUser) {
      console.log(`[Logout] Backing up data for ${currentUser.email}...`);
      await triggerSaveAll(
        profile,
        skills,
        education,
        certifications,
        experience,
        currentJob,
        projects,
        products,
        others,
        links,
        resumeLinks,
        milestones,
        contacts,
        achievements,
        testimonials,
        documents,
        calendarEvents,
        notes,
        resumes
      );
      console.log(`[Logout] Backup completed.`);
    }

    setProfile(EMPTY_PROFILE);
    setSkills([]);
    setEducation([]);
    setCertifications([]);
    setExperience([]);
    setCurrentJob(EMPTY_CURRENT_JOB);
    setProjects([]);
    setProducts([]);
    setOthers([]);
    setLinks([]);
    setResumeLinks([]);
    setMilestones([]);
    setContacts([]);
    setAchievements([]);
    setTestimonials([]);
    setDocuments([]);
    setCalendarEvents([]);
    setNotes([]);
    setResumes([]);

    lastLoadedEmailRef.current = null;
    setCurrentUser(null);
  };


  // 3. Operational CRUD handlers

  // Skills
  const handleAddSkill = (newSk: Omit<Skill, 'id'>) => {
    const skill: Skill = { ...newSk, id: `sk-${Date.now()}` };
    setSkills(prev => [skill, ...prev]);
    triggerToast(`Exposed technical skill capability: ${newSk.name}`);
  };

  const handleUpdateSkill = (upSkill: Skill) => {
    setSkills(prev => prev.map(s => s.id === upSkill.id ? upSkill : s));
    triggerToast(`Optimized technical status: ${upSkill.name}`);
  };

  const handleDeleteSkill = (id: string) => {
    setSkills(prev => prev.filter(s => s.id !== id));
    triggerToast(`Purged technical coordinate.`);
  };

  // Education
  const handleAddEdu = (newEd: Omit<Education, 'id'>) => {
    const eduItem: Education = { ...newEd, id: `ed-${Date.now()}` };
    setEducation(prev => [eduItem, ...prev]);
    triggerToast(`Appended academic credential: ${newEd.degree}`);
  };

  const handleDeleteEdu = (id: string) => {
    setEducation(prev => prev.filter(e => e.id !== id));
    triggerToast(`Removed academic snapshot.`);
  };

  const handleUpdateEdu = (updatedEd: Education) => {
    setEducation(prev => prev.map(e => e.id === updatedEd.id ? updatedEd : e));
    triggerToast(`Updated academic credential: ${updatedEd.degree}`);
  };

  // Certifications
  const handleAddCert = (newCert: Omit<Certification, 'id'>) => {
    const cert: Certification = { ...newCert, id: `cert-${Date.now()}` };
    setCertifications(prev => [cert, ...prev]);
    triggerToast(`Exposed regulatory certificate: ${newCert.title}`);
  };

  const handleDeleteCert = (id: string) => {
    setCertifications(prev => prev.filter(c => c.id !== id));
    triggerToast(`Wiped credential clearance.`);
  };

  const handleUpdateCert = (updatedCert: Certification) => {
    setCertifications(prev => prev.map(c => c.id === updatedCert.id ? updatedCert : c));
    triggerToast(`Updated file attachment for: ${updatedCert.title}`);
  };

  // Experience
  const handleAddExp = (newExp: Omit<Experience, 'id'>) => {
    const exp: Experience = { ...newExp, id: `exp-${Date.now()}` };
    setExperience(prev => [exp, ...prev]);
    triggerToast(`Registered employment tenure: ${newExp.role}`);
  };

  const handleDeleteExp = (id: string) => {
    setExperience(prev => prev.filter(e => e.id !== id));
    triggerToast(`Cleared historic experience milestone.`);
  };

  // Projects & Products & Others
  const handleAddProj = (newPr: Omit<Project, 'id'>) => {
    const proj: Project = { ...newPr, id: `proj-${Date.now()}-${Math.random().toString(36).substring(2, 7)}` };
    if (newPr.type === 'product') {
      const updatedProducts = [proj, ...products];
      setProducts(updatedProducts);
      triggerToast(`Published product assets: ${newPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, projects, updatedProducts, others);
    } else if (newPr.type === 'other') {
      const updatedOthers = [proj, ...others];
      setOthers(updatedOthers);
      triggerToast(`Added document: ${newPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, projects, products, updatedOthers);
    } else {
      const updatedProjects = [proj, ...projects];
      setProjects(updatedProjects);
      triggerToast(`Published project assets: ${newPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, updatedProjects, products, others);
    }
  };

  const handleDeleteProj = (id: string) => {
    const updatedProjects = projects.filter(p => p.id !== id);
    const updatedProducts = products.filter(p => p.id !== id);
    const updatedOthers = others.filter(p => p.id !== id);
    setProjects(updatedProjects);
    setProducts(updatedProducts);
    setOthers(updatedOthers);
    triggerToast(`Archived record.`);
    triggerSaveAll(profile, skills, education, certifications, experience, currentJob, updatedProjects, updatedProducts, updatedOthers);
  };

  const handleUpdateProj = (updatedPr: Project) => {
    if (updatedPr.type === 'product') {
      const updatedProducts = products.map(p => p.id === updatedPr.id ? updatedPr : p);
      setProducts(updatedProducts);
      triggerToast(`Updated product assets: ${updatedPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, projects, updatedProducts, others);
    } else if (updatedPr.type === 'other') {
      const updatedOthers = others.map(p => p.id === updatedPr.id ? updatedPr : p);
      setOthers(updatedOthers);
      triggerToast(`Updated document: ${updatedPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, projects, products, updatedOthers);
    } else {
      const updatedProjects = projects.map(p => p.id === updatedPr.id ? updatedPr : p);
      setProjects(updatedProjects);
      triggerToast(`Updated project assets: ${updatedPr.name}`);
      triggerSaveAll(profile, skills, education, certifications, experience, currentJob, updatedProjects, products, others);
    }
  };

  // Portfolio Links
  const handleAddLink = (newLk: Omit<PortfolioLink, 'id'>) => {
    const link: PortfolioLink = { ...newLk, id: `lk-${Date.now()}` };
    setLinks(prev => [link, ...prev]);
    triggerToast(`Published portal entry: ${newLk.label}`);
  };

  const handleDeleteLink = (id: string) => {
    setLinks(prev => prev.filter(l => l.id !== id));
    triggerToast(`Closed link coordinates.`);
  };

  const handleUpdateLink = (updatedLk: PortfolioLink) => {
    setLinks(prev => prev.map(l => l.id === updatedLk.id ? updatedLk : l));
    triggerToast(`Updated portal entry: ${updatedLk.label}`);
  };

  // Resume Links Handlers
  const handleAddResumeLink = (newLk: Omit<PortfolioLink, 'id'>) => {
    const link: PortfolioLink = { ...newLk, id: `reslk-${Date.now()}` };
    setResumeLinks(prev => [link, ...prev]);
    triggerToast(`Added resume link: ${newLk.label}`);
  };

  const handleDeleteResumeLink = (id: string) => {
    setResumeLinks(prev => prev.filter(l => l.id !== id));
    triggerToast(`Removed resume link.`);
  };

  const handleUpdateResumeLink = (updatedLk: PortfolioLink) => {
    setResumeLinks(prev => prev.map(l => l.id === updatedLk.id ? updatedLk : l));
    triggerToast(`Updated resume link: ${updatedLk.label}`);
  };

  // Milestones
  const handleAddMilestone = (newMil: Omit<TimelineMilestone, 'id'>) => {
    const mil: TimelineMilestone = { ...newMil, id: `mil-${Date.now()}` };
    setMilestones(prev => [mil, ...prev]);
    triggerToast(`Published career milestone checkpoint.`);
  };

  const handleDeleteMilestone = (id: string) => {
    setMilestones(prev => prev.filter(m => m.id !== id));
    triggerToast(`Purged timeline checkpoint.`);
  };

  // Contacts CRM
  const handleAddContact = (newCt: Omit<Contact, 'id' | 'interactionLogs'>) => {
    const contact: Contact = { ...newCt, id: `ct-${Date.now()}`, interactionLogs: [] };
    setContacts(prev => [contact, ...prev]);
    triggerToast(`Added pipeline network coordinate: ${newCt.name}`);
  };

  const handleDeleteContact = (id: string) => {
    setContacts(prev => prev.filter(c => c.id !== id));
    triggerToast(`Transferred contact records off-grid.`);
  };

  const handleUpdateContact = (updatedCt: Contact) => {
    setContacts(prev => prev.map(c => c.id === updatedCt.id ? updatedCt : c));
    triggerToast(`Updated connection coordinates for: ${updatedCt.name}`);
  };

  const handleAddInteraction = (contactId: string, log: { type: 'email' | 'call' | 'meeting' | 'note'; summary: string }) => {
    setContacts(prev => prev.map(ct => {
      if (ct.id === contactId) {
        const fullLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          ...log
        };
        return {
          ...ct,
          lastInteracted: new Date().toISOString().substring(0, 10),
          interactionLogs: [fullLog, ...(ct.interactionLogs || [])]
        };
      }
      return ct;
    }));
    triggerToast(`Logged connection sync transaction.`);
  };

  // Achievements
  const handleAddAchievement = (newAch: Omit<Achievement, 'id'>) => {
    const ach: Achievement = { ...newAch, id: `ach-${Date.now()}` };
    setAchievements(prev => [ach, ...prev]);
    triggerToast(`Acquired industry award validation!`);
  };

  const handleDeleteAchievement = (id: string) => {
    setAchievements(prev => prev.filter(a => a.id !== id));
    triggerToast(`Purged award snapshot.`);
  };

  // Testimonials
  const handleAddTestimonial = (newRec: Omit<Testimonial, 'id'>) => {
    const rec: Testimonial = { ...newRec, id: `rec-${Date.now()}` };
    setTestimonials(prev => [rec, ...prev]);
    triggerToast(`Published peer quote endorsement.`);
  };

  const handleDeleteTestimonial = (id: string) => {
    setTestimonials(prev => prev.filter(t => t.id !== id));
    triggerToast(`Removed endorsement quote.`);
  };

  // Documents
  const handleAddDocument = (newDoc: Omit<VaultDocument, 'id'>) => {
    const isDuplicate = documents.some(d => d.name === newDoc.name && d.size === newDoc.size);
    if (isDuplicate) return;

    const doc: VaultDocument = { 
      ...newDoc, 
      id: `doc-${Date.now()}-${Math.floor(Math.random() * 1000000)}` 
    };
    
    setDocuments(prev => [doc, ...prev]);
    triggerToast(`Secured vault backup file: ${newDoc.name}`);
  };

  const handleDeleteDocument = (id: string) => {
    const docToDelete = documents.find(d => d.id === id);
    const docName = docToDelete ? docToDelete.name : "document";
    setDocuments(prev => prev.filter(d => d.id !== id));
    triggerToast(`Removed "${docName}" from document vault.`);
  };

  // Calendar Events
  const handleAddCalendarEvent = (newEvt: Omit<CalendarEvent, 'id'>) => {
    const evt: CalendarEvent = { ...newEvt, id: `evt-${Date.now()}` };
    setCalendarEvents(prev => [evt, ...prev]);
    triggerToast(`Added scheduled event: "${newEvt.title}"`);
  };

  const handleUpdateCalendarEvent = (updatedEvt: CalendarEvent) => {
    setCalendarEvents(prev => prev.map(evt => evt.id === updatedEvt.id ? updatedEvt : evt));
    triggerToast(`Updated scheduled event: "${updatedEvt.title}"`);
  };

  const handleDeleteCalendarEvent = (id: string) => {
    const evtToDelete = calendarEvents.find(e => e.id === id);
    const titleVal = evtToDelete ? evtToDelete.title : "event";
    setCalendarEvents(prev => prev.filter(e => e.id !== id));
    triggerToast(`Deleted scheduled event: "${titleVal}"`);
  };

  // Restores defaults
  const handleRestoreDefaults = () => {
    setConfirmDialog({
      title: "Restore Default Database",
      message: "Are you sure you want to restore all values to Ramachandra Murthy Mamidipalli ('Murthy AM') professional database? This overwrites custom configurations.",
      onConfirm: () => {
        setProfile(INITIAL_PROFILE);
        setSkills(INITIAL_SKILLS);
        setEducation(INITIAL_EDUCATION);
        setCertifications(INITIAL_CERTIFICATIONS);
        setExperience(INITIAL_EXPERIENCE);
        setCurrentJob(INITIAL_CURRENT_JOB);
        
        // Split defaults
        const demoProjects = INITIAL_PROJECTS.filter(p => p.type !== 'product');
        const demoProducts = INITIAL_PROJECTS.filter(p => p.type === 'product');
        setProjects(demoProjects);
        setProducts(demoProducts);

        setLinks(INITIAL_LINKS);
        setResumeLinks([]);

        setMilestones(INITIAL_TIMELINE);
        setContacts(INITIAL_CONTACTS);
        setAchievements(INITIAL_ACHIEVEMENTS);
        setTestimonials(INITIAL_TESTIMONIALS);
        setDocuments(INITIAL_DOCUMENTS);
        setCalendarEvents(INITIAL_CALENDAR_EVENTS);
        setConfirmDialog(null);
        triggerToast("Career intelligence matrices restored successfully.");
      }
    });
  };

  const handleWipeData = () => {
    setProfile({ name: '', headline: '', email: '', phone: '', location: '', bio: '', avatarUrl: '' });
    setSkills([]);
    setEducation([]);
    setCertifications([]);
    setExperience([]);
    setCurrentJob({ employer: '', role: '', startDate: '', department: '', currentProjects: [], dailyStandupText: '', weeklyGoals: [] });
    setProjects([]);
    setProducts([]);
    setLinks([]);
    setResumeLinks([]);
    setMilestones([]);
    setContacts([]);
    setAchievements([]);
    setTestimonials([]);
    setDocuments([]);
    triggerToast("All stored structures cleaned.");
  };

  // Recursively strips heavy base64 items (e.g. uploaded PDFs or massive image files)
  // to ensure URLs fit comfortably within standard browser URL limits (approx. 2000-8000 characters).
  const stripLargeBase64 = (obj: any, key?: string): any => {
    if (obj === null || obj === undefined) return obj;
    if (typeof obj === 'string') {
      if (obj.startsWith('data:') && obj.length > 500) {
        if (key === 'avatarUrl') {
          // Allow profile picture base64 up to 1,500,000 characters (approx 1.1MB)
          if (obj.length > 1500000) {
            return '[Large avatar truncated for size limits]';
          }
          return obj;
        }
        return '[Large attachment truncated for optimization]';
      }
      return obj;
    }
    if (Array.isArray(obj)) {
      return obj.map(item => stripLargeBase64(item));
    }
    if (typeof obj === 'object') {
      const newObj: any = {};
      for (const k in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, k)) {
          newObj[k] = stripLargeBase64(obj[k], k);
        }
      }
      return newObj;
    }
    return obj;
  };

  const getFullShareUrl = () => {
    const shareSlug = profile.name ? profile.name.toLowerCase().replace(/\s+/g, '-') : 'ramachandra-murthy';
    return `${window.location.origin}/#/public/${shareSlug}`;
  };

  // Check if current view is a public share URL (either by path, hash, or query parameter)
  const isPublicShareView = window.location.pathname.startsWith('/share/') || 
                            window.location.hash.startsWith('#/share/') || 
                            window.location.pathname.startsWith('/public/') || 
                            window.location.hash.startsWith('#/public/') || 
                            window.location.pathname.startsWith('/profile/') || 
                            window.location.hash.startsWith('#/profile/') || 
                            window.location.search.includes('share=');

  // Automated public cloud synchronization effect
  useEffect(() => {
    if (!currentUser) return;
    const email = currentUser.email.toLowerCase().trim();
    if (lastLoadedEmailRef.current !== email) return;

    // 1. Save to local storage synchronously and immediately as offline backup
    safeLocalStorageSetItem(`${email}_profile`, JSON.stringify(profile));
    safeLocalStorageSetItem(`${email}_skills`, JSON.stringify(skills));
    safeLocalStorageSetItem(`${email}_education`, JSON.stringify(education));
    safeLocalStorageSetItem(`${email}_certs`, JSON.stringify(certifications));
    safeLocalStorageSetItem(`${email}_experience`, JSON.stringify(experience));
    safeLocalStorageSetItem(`${email}_current_job`, JSON.stringify(currentJob));
    safeLocalStorageSetItem(`${email}_projects`, JSON.stringify(projects));
    safeLocalStorageSetItem(`${email}_products`, JSON.stringify(products));
    safeLocalStorageSetItem(`${email}_links`, JSON.stringify(links));
    safeLocalStorageSetItem(`${email}_resume_links`, JSON.stringify(resumeLinks));
    safeLocalStorageSetItem(`${email}_milestones`, JSON.stringify(milestones));
    safeLocalStorageSetItem(`${email}_contacts`, JSON.stringify(contacts));
    safeLocalStorageSetItem(`${email}_achievements`, JSON.stringify(achievements));
    safeLocalStorageSetItem(`${email}_testimonials`, JSON.stringify(testimonials));
    safeLocalStorageSetItem(`${email}_documents`, JSON.stringify(documents));
    safeLocalStorageSetItem(`${email}_calendar_events`, JSON.stringify(calendarEvents));
    safeLocalStorageSetItem(`${email}_notepad_notes`, JSON.stringify(notes));
    safeLocalStorageSetItem(`${email}_nexus_vault_resumes`, JSON.stringify(resumes));

    // 2. debounce to avoid excessive REST request flooding on fast inputs
    const timer = setTimeout(() => {
      const shareSlug = profile.name ? profile.name.toLowerCase().replace(/\s+/g, '-') : 'ramachandra-murthy';
      
      // CRITICAL SECURITY ENHANCEMENT: Filter out anything that the user selected as "private"
      // so that private items are STRICTLY excluded from the public serialized payload.
      const publicSkillsOnly = skills.filter(s => s.visibility === 'public');
      const publicCertsOnly = certifications.filter(c => c.visibility === 'public').map(c => {
        // Strip out large attachments for serialization to protect link size limits and speed optimization
        if (c.fileUrl && c.fileUrl.startsWith('data:')) {
          return { ...c, fileUrl: '[Uploaded Document Cached]' };
        }
        return c;
      });
      const publicCalendarOnly = calendarEvents.filter(evt => evt.isPublic !== false);
      const publicLinksOnly = [...links, ...resumeLinks].filter(lk => lk.isPublic !== false);
      const publicProjectsOnly = [...projects, ...products].filter(proj => proj.isPublic !== false);

      // Deduplicate arrays with a precise key comparison to prevent payload duplicates
      const deduplicatePayloadArray = <T extends { id?: string }>(arr: T[], getFallbackKey: (item: any) => string): T[] => {
        if (!arr || !Array.isArray(arr)) return [];
        const seenIds = new Set<string>();
        const seenKeys = new Set<string>();
        return arr.filter(item => {
          if (!item) return false;
          const id = item.id;
          const fallbackKey = getFallbackKey(item).toLowerCase().trim();
          if (id) {
            if (seenIds.has(id)) return false;
            seenIds.add(id);
          }
          if (fallbackKey) {
            if (seenKeys.has(fallbackKey)) return false;
            seenKeys.add(fallbackKey);
          }
          return true;
        });
      };

      const deduplicatedSkills = deduplicatePayloadArray(publicSkillsOnly, sk => sk.name || '');
      const deduplicatedExperience = deduplicatePayloadArray(experience, exp => `${exp.role || ''}-${exp.company || ''}`);
      const deduplicatedCerts = deduplicatePayloadArray(publicCertsOnly, c => c.title || '');
      const deduplicatedProjects = deduplicatePayloadArray(publicProjectsOnly, proj => proj.name || '');
      const deduplicatedEducation = deduplicatePayloadArray(education, edu => `${edu.degree || ''}-${edu.institution || ''}`);
      const deduplicatedAchievements = deduplicatePayloadArray(achievements, ach => ach.title || '');
      const deduplicatedTestimonials = deduplicatePayloadArray(testimonials, rec => `${rec.name || ''}-${rec.company || ''}`);
      const deduplicatedLinks = deduplicatePayloadArray(publicLinksOnly, lk => lk.url || '');
      const deduplicatedPlatformEvents = deduplicatePayloadArray(publicCalendarOnly, evt => `${evt.title || ''}-${evt.date || ''}`);

      const payload = {
        p: profile,
        s: deduplicatedSkills,
        e: deduplicatedExperience,
        c: deduplicatedCerts,
        pr: deduplicatedProjects,
        ed: deduplicatedEducation,
        a: deduplicatedAchievements,
        t: deduplicatedTestimonials,
        l: deduplicatedLinks,
        cal: deduplicatedPlatformEvents
      };
      
      const serialized = encodePortfolioData(stripLargeBase64(payload));

      // Private complete user database payload for flawless cross-device backup recovery
      const completeUserData = {
        profile,
        skills,
        education,
        certifications,
        experience,
        currentJob,
        projects,
        products,
        links,
        resumeLinks,
        milestones,
        contacts,
        achievements,
        testimonials,
        documents,
        calendarEvents,
        notes,
        resumes
      };

      const publishToCloud = async () => {
        // First, backup full user profile catalog to the userdata endpoint
        try {
          await apiFetch(`/api/userdata/${encodeURIComponent(email)}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: JSON.stringify(completeUserData) })
          });
          console.log(`[Backup Sync] Full userdata backup persisted successfully for email ${email}`);
          // Clear pending sync on successful upload
          localStorage.removeItem(`nexus_pending_sync_${email}`);
        } catch (e) {
          console.log("[Backup Sync] Failed to sync full userdata to server:", e);
          // Store in pending queue to sync later
          localStorage.setItem(`nexus_pending_sync_${email}`, JSON.stringify({
            email,
            data: completeUserData,
            timestamp: Date.now()
          }));
        }

        // Clean sync directly to our custom Express backend API relative path
        try {
          await apiFetch(`/api/share/${shareSlug}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ serialized })
          });
          console.log(`[Auto-Publish] Synced successfully with server cache service for slug: ${shareSlug}`);
        } catch (err) {
          console.log(`[Auto-Publish] Express Sync deferred for ${shareSlug}.`);
        }
      };

      publishToCloud();
    }, 1500);

    return () => clearTimeout(timer);
  }, [profile, skills, experience, certifications, projects, products, education, achievements, testimonials, links, resumeLinks, calendarEvents, notes, resumes, currentUser]);

  // Async loader side effect for clean multi-device shared URLs
  useEffect(() => {
    if (!isPublicShareView) return;

    let active = true;

    // Parse slug from URL (path or hash)
    let slug = 'ramachandra-murthy';
    const currentHash = window.location.hash || '';
    const currentPathname = window.location.pathname || '';
    
    if (currentHash.startsWith('#/share/')) {
      const parts = currentHash.split('?');
      slug = parts[0].replace('#/share/', '');
    } else if (currentHash.startsWith('#/public/')) {
      const parts = currentHash.split('?');
      slug = parts[0].replace('#/public/', '');
    } else if (currentHash.startsWith('#/profile/')) {
      const parts = currentHash.split('?');
      slug = parts[0].replace('#/profile/', '');
    } else if (currentPathname.startsWith('/share/')) {
      const parts = currentPathname.split('?');
      slug = parts[0].replace('/share/', '');
    } else if (currentPathname.startsWith('/public/')) {
      const parts = currentPathname.split('?');
      slug = parts[0].replace('/public/', '');
    } else if (currentPathname.startsWith('/profile/')) {
      const parts = currentPathname.split('?');
      slug = parts[0].replace('/profile/', '');
    }
    slug = slug.split('/')[0].trim().toLowerCase();
    if (slug === 'ramachandra-murthy' || slug === 'ramachandramurthy' || slug === 'ramachandra-murthy-mamidipalli') {
      slug = 'murthy-m';
    }

    // Check if it's the official mockup demo / template (only these fall back to mock placeholder data!)
    const isDemo = slug === 'demo' || slug === 'template';

    // Baseline shared variables (starts with default fallback or empty depending on owner)
    let sharedProfile = isDemo ? INITIAL_PROFILE : EMPTY_PROFILE;
    let sharedSkills = isDemo ? INITIAL_SKILLS : [];
    let sharedExperience = isDemo ? INITIAL_EXPERIENCE : [];
    let sharedCertifications = isDemo ? INITIAL_CERTIFICATIONS : [];
    let sharedProjects = isDemo ? INITIAL_PROJECTS : [];
    let sharedEducation = isDemo ? INITIAL_EDUCATION : [];
    let sharedAchievements = isDemo ? INITIAL_ACHIEVEMENTS : [];
    let sharedTestimonials = isDemo ? INITIAL_TESTIMONIALS : [];
    let sharedLinks = isDemo ? INITIAL_LINKS : [];
    let sharedCalendarEvents = isDemo ? INITIAL_CALENDAR_EVENTS : [];

    // Find if any registered user matches this slug
    let matchedEmail: string | null = null;
    const registeredUsers: any[] = [];
    const savedUsersJSON = localStorage.getItem('nexus_registered_users');
    if (savedUsersJSON) {
      try {
        const parsed = JSON.parse(savedUsersJSON);
        if (Array.isArray(parsed)) {
          registeredUsers.push(...parsed);
        }
      } catch (e) {}
    }

    // Also include currently logged-in user if not already in the list
    const currentEmail = getCurrentUserEmail();
    if (currentEmail && !registeredUsers.some(u => u.email === currentEmail)) {
      registeredUsers.push({ email: currentEmail, isMailOnly: false });
    }

    // Scan all possible profiles on this machine to find the one matching the current slug
    for (const u of registeredUsers) {
      const savedProfileStr = localStorage.getItem(`${u.email}_profile`);
      if (savedProfileStr) {
        try {
          const p = JSON.parse(savedProfileStr);
          if (p && p.name) {
            const candidateSlug = p.name.toLowerCase().replace(/\s+/g, '-');
            if (candidateSlug === slug) {
              matchedEmail = u.email;
              break;
            }
          }
        } catch (e) {}
      }
    }

    // Fallback if matched Email holds empty profile details:
    if (!matchedEmail && currentEmail && (slug === 'ramachandra-murthy' || slug === 'murthy-m' || slug === 'ramachandra-murthy-mamidipalli')) {
      matchedEmail = currentEmail;
    }

    // Try loading actual local edits from localStorage first (for zero-latency on native creator machine)
    if (matchedEmail) {
      const getLocalData = (keySuffix: string) => {
        const saved = localStorage.getItem(`${matchedEmail}_${keySuffix}`);
        if (saved) {
          try { return JSON.parse(saved); } catch (e) {}
        }
        return null;
      };
      
      const locP = getLocalData('profile');
      const locS = getLocalData('skills');
      const locE = getLocalData('experience');
      const locC = getLocalData('certs');
      const locPr = getLocalData('projects');
      const locProd = getLocalData('products');
      const locOth = getLocalData('others');
      const locEd = getLocalData('education');
      const locA = getLocalData('achievements');
      const locT = getLocalData('testimonials');
      const locL = getLocalData('links');
      const locResL = getLocalData('resume_links');
      const locCal = getLocalData('calendar_events');

      sharedProfile = locP !== null ? locP : (isDemo ? INITIAL_PROFILE : EMPTY_PROFILE);
      sharedSkills = locS !== null ? locS : (isDemo ? INITIAL_SKILLS : []);
      sharedExperience = locE !== null ? locE : (isDemo ? INITIAL_EXPERIENCE : []);
      sharedCertifications = locC !== null ? locC : (isDemo ? INITIAL_CERTIFICATIONS : []);
      sharedProjects = (locPr !== null || locProd !== null || locOth !== null) 
        ? [...(locPr || []), ...(locProd || []), ...(locOth || [])] 
        : (isDemo ? INITIAL_PROJECTS : []);
      sharedEducation = locEd !== null ? locEd : (isDemo ? INITIAL_EDUCATION : []);
      sharedAchievements = locA !== null ? locA : (isDemo ? INITIAL_ACHIEVEMENTS : []);
      sharedTestimonials = locT !== null ? locT : (isDemo ? INITIAL_TESTIMONIALS : []);
      sharedLinks = (locL !== null || locResL !== null) ? [...(locL || []), ...(locResL || [])] : (isDemo ? INITIAL_LINKS : []);
      sharedCalendarEvents = locCal !== null ? locCal : (isDemo ? INITIAL_CALENDAR_EVENTS : []);
    } else {
      // Direct offline read-only local storage fallback
      const cachedProfileStr = localStorage.getItem(`nexus_cache_profile_${slug}`);
      if (cachedProfileStr) {
        try {
          sharedProfile = JSON.parse(cachedProfileStr);
          const getCachedData = (keySuffix: string, fallback: any) => {
            const saved = localStorage.getItem(`nexus_cache_${keySuffix}_${slug}`);
            if (saved) {
              try { return JSON.parse(saved); } catch (e) {}
            }
            return fallback;
          };
          sharedSkills = getCachedData('skills', sharedSkills);
          sharedExperience = getCachedData('experience', sharedExperience);
          sharedCertifications = getCachedData('certs', sharedCertifications);
          sharedProjects = getCachedData('projects', sharedProjects);
          sharedEducation = getCachedData('education', sharedEducation);
          sharedAchievements = getCachedData('achievements', sharedAchievements);
          sharedTestimonials = getCachedData('testimonials', sharedTestimonials);
          sharedLinks = getCachedData('links', sharedLinks);
          sharedCalendarEvents = getCachedData('calendar_events', sharedCalendarEvents);
        } catch (e) {}
      }
    }

    // Set immediate cached/sync state so ui feels instant
    if (active) {
      setRemoteShareData({
        profile: sharedProfile,
        skills: sharedSkills,
        experience: sharedExperience,
        certifications: sharedCertifications,
        projects: sharedProjects,
        education: sharedEducation,
        achievements: sharedAchievements,
        testimonials: sharedTestimonials,
        links: sharedLinks,
        calendarEvents: sharedCalendarEvents
      });
    }

    // Sync Query param as fallback override
    const getQueryParamFromUrl = (param: string): string | null => {
      try {
        const searchParams = new URLSearchParams(window.location.search);
        let val = searchParams.get(param);
        if (val) return val;
        
        const hash = window.location.hash;
        const parts = hash.split('?');
        if (parts.length > 1) {
          const hashParams = new URLSearchParams(parts[1]);
          return hashParams.get(param);
        }
      } catch (e) {
        console.error(e);
      }
      return null;
    };

    let lastFetchedText = "";

    const applyDecodedTextPayload = (text: string) => {
      if (!active || !text || text === lastFetchedText) return;
      
      const decoded = decodePortfolioData(text);
      if (decoded) {
        lastFetchedText = text;
        const finalData = {
          profile: decoded.p ? { ...decoded.p, publicProfile: true } : { ...sharedProfile, publicProfile: true },
          skills: decoded.s || sharedSkills,
          experience: decoded.e || sharedExperience,
          certifications: decoded.c || sharedCertifications,
          projects: decoded.pr || sharedProjects,
          education: decoded.ed || sharedEducation,
          achievements: decoded.a || sharedAchievements,
          testimonials: decoded.t || sharedTestimonials,
          links: decoded.l || sharedLinks,
          calendarEvents: decoded.cal || []
        };
        setRemoteShareData(finalData);

        // Back up Cache for future offline review
        try {
          localStorage.setItem(`nexus_cache_profile_${slug}`, JSON.stringify(finalData.profile));
          localStorage.setItem(`nexus_cache_skills_${slug}`, JSON.stringify(finalData.skills));
          localStorage.setItem(`nexus_cache_experience_${slug}`, JSON.stringify(finalData.experience));
          localStorage.setItem(`nexus_cache_certs_${slug}`, JSON.stringify(finalData.certifications));
          localStorage.setItem(`nexus_cache_projects_${slug}`, JSON.stringify(finalData.projects));
          localStorage.setItem(`nexus_cache_education_${slug}`, JSON.stringify(finalData.education));
          localStorage.setItem(`nexus_cache_achievements_${slug}`, JSON.stringify(finalData.achievements));
          localStorage.setItem(`nexus_cache_testimonials_${slug}`, JSON.stringify(finalData.testimonials));
          localStorage.setItem(`nexus_cache_links_${slug}`, JSON.stringify(finalData.links));
          localStorage.setItem(`nexus_cache_calendar_events_${slug}`, JSON.stringify(finalData.calendarEvents));
        } catch (e) {}
      }
    };

    const dParam = getQueryParamFromUrl('d');
    if (dParam) {
      applyDecodedTextPayload(dParam);
      // We set loadingRemoteShare to false so the user immediately gets a rendered page from dParam snapshot.
      setLoadingRemoteShare(false);
    }

    // Async Fetch from our server-side database with sequential fallback layers for bulletproof availability
    if (!dParam) {
      setLoadingRemoteShare(true);
    }
    
    const fetchWithFallback = async () => {
      try {
        console.log(`[Sync] Reading share data for slug '${slug}' from unified storage...`);
        const res = await apiFetch(`/api/share/${slug}`);
        if (!res.ok) {
          throw new Error(`HTTP Error ${res.status}`);
        }
        const data = await res.json();
        const serializedText = data?.serialized;
        if (serializedText && serializedText.trim().length > 10) {
          console.log(`[Sync] Success: Primary App Server API`);
          return serializedText;
        } else {
          throw new Error("Invalid or empty payload value");
        }
      } catch (err: any) {
        console.log(`[Sync] Failed: Primary App Server API - ${err.message || err}`);
      }

      // 2. Fallback to cache
      console.log(`[Sync] Falling back to local offline cache...`);
      try {
        const cachedProfile = localStorage.getItem(`nexus_cache_profile_${slug}`);
        if (cachedProfile) {
          const finalData = {
            profile: { ...JSON.parse(cachedProfile), publicProfile: true },
            skills: JSON.parse(localStorage.getItem(`nexus_cache_skills_${slug}`) || "[]"),
            experience: JSON.parse(localStorage.getItem(`nexus_cache_experience_${slug}`) || "[]"),
            certifications: JSON.parse(localStorage.getItem(`nexus_cache_certs_${slug}`) || "[]"),
            projects: JSON.parse(localStorage.getItem(`nexus_cache_projects_${slug}`) || "[]"),
            education: JSON.parse(localStorage.getItem(`nexus_cache_education_${slug}`) || "[]"),
            achievements: JSON.parse(localStorage.getItem(`nexus_cache_achievements_${slug}`) || "[]"),
            testimonials: JSON.parse(localStorage.getItem(`nexus_cache_testimonials_${slug}`) || "[]"),
            links: JSON.parse(localStorage.getItem(`nexus_cache_links_${slug}`) || "[]"),
            calendarEvents: JSON.parse(localStorage.getItem(`nexus_cache_calendar_events_${slug}`) || "[]")
          };
          setRemoteShareData(finalData);
          console.log(`[Sync] Successfully restored from local offline Cache backup.`);
          return "";
        }
      } catch (cacheErr) {
        console.log("[Sync] Stale local offline cache failed:", cacheErr);
      }

      throw new Error("All storage recovery sources depleted during retrieval attempt");
    };

    // Initial load live fetch
    fetchWithFallback()
      .then(text => {
        if (text) {
          applyDecodedTextPayload(text);
        }
      })
      .catch(e => {
        console.log("KV cloud payload fetch error (falling back to local layout cache):", e);
      })
      .finally(() => {
        if (active) {
          setLoadingRemoteShare(false);
        }
      });

    // Smart background interval to dynamically auto-sync real-time edits while visitor has page open
    const interval = setInterval(() => {
      fetchWithFallback()
        .then(text => {
          if (text) {
            applyDecodedTextPayload(text);
          }
        })
        .catch(e => {
          console.log("[Sync] Background polling check failed:", e);
        });
    }, 7500); // Check for real-time CRM updates every 7.5 seconds

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [isPublicShareView]);

  if (isPublicShareView) {
    if (loadingRemoteShare && (!remoteShareData || !remoteShareData.profile.name)) {
      return (
        <div className="min-h-screen bg-[#07080b] flex flex-col justify-center items-center font-sans select-none relative overflow-hidden" id="nexus-share-loader">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[140px] bg-emerald-500/10 pointer-events-none" />
          <div className="z-10 text-center space-y-6 max-w-sm px-6 animate-pulse">
            <div className="relative inline-flex">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400/10 animate-ping" />
              <div className="relative rounded-full border border-emerald-500/30 p-4 bg-slate-950/80 shadow-2xl">
                <Sparkles className="w-8 h-8 text-emerald-400 animate-spin" />
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="text-white font-extrabold text-[10px] tracking-widest uppercase font-mono">Consuming Nexus Registries</h2>
              <p className="text-xs text-gray-500 font-mono leading-relaxed">
                Loading secure high-contrast career database telemetry files...
              </p>
            </div>
          </div>
        </div>
      );
    }

    if (!remoteShareData) {
      return (
        <div className="min-h-screen bg-[#07080b] flex flex-col justify-center items-center font-sans select-none relative overflow-hidden" id="nexus-share-error">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[140px] bg-red-500/10 pointer-events-none" />
          <div className="z-10 text-center space-y-6 max-w-sm px-6">
            <div className="relative inline-flex">
              <div className="relative rounded-full border border-red-500/30 p-4 bg-slate-950/80 shadow-2xl">
                <AlertTriangle className="w-8 h-8 text-red-400 animate-pulse" />
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="text-white font-extrabold text-xs tracking-widest uppercase font-mono">Registry Retrieval Error</h2>
              <p className="text-xs text-gray-400 font-mono leading-relaxed bg-slate-950/60 p-3.5 border border-slate-900 rounded-xl">
                The network was unable to pull secure resume telemetry files from cloud databases.
              </p>
            </div>
            <button 
              type="button"
              onClick={() => {
                window.location.reload();
              }}
              className="flex items-center gap-2 text-xs font-semibold text-gray-400 hover:text-white transition cursor-pointer select-none bg-slate-900 border border-slate-800 py-1.5 px-4 rounded-xl mx-auto active:scale-95"
            >
              <span>Retry Sync</span>
            </button>
          </div>
        </div>
      );
    }

    return (
      <PublicPortfolioView 
        profile={remoteShareData.profile}
        skills={remoteShareData.skills}
        experience={remoteShareData.experience}
        certifications={remoteShareData.certifications}
        projects={remoteShareData.projects}
        education={remoteShareData.education}
        achievements={remoteShareData.achievements}
        testimonials={remoteShareData.testimonials}
        links={remoteShareData.links}
        calendarEvents={remoteShareData.calendarEvents || []}
      />
    );
  }

  if (!currentUser) {
    return (
      <div className="relative">
        <AuthPage onLoginSuccess={handleUserLogin} triggerToast={triggerToast} />
        {/* Render persistent toast for auth feedback */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 bg-[#0d0e12] border border-emerald-500/30 text-emerald-400 px-4 py-3 rounded-xl text-xs flex items-center gap-2 z-50 shadow-xl animate-fade-in" id="nexus-auth-toast">
            <span className="font-sans font-semibold text-gray-200">{toastMessage}</span>
          </div>
        )}
      </div>
    );
  }

  // Clean Sidebar items rendering configuration
  const sidebarItems = [
    { id: 'overview', label: 'Home Page', icon: Home },
    { id: 'profile', label: 'Personal Profile', icon: User },
    { id: 'skills', label: 'Skills', icon: Cpu },
    { id: 'education', label: 'Education', icon: GraduationCap },
    { id: 'certifications', label: 'Certifications', icon: Award },
    { id: 'experience', label: 'Experience', icon: Briefcase },
    { id: 'current-job', label: 'Current Job', icon: Laptop },
    { id: 'projects', label: 'Projects & Products', icon: Rocket },
    { id: 'resume', label: 'Resume / CV', icon: FileText },
    { id: 'portfolios', label: 'Portfolios & Links', icon: Link2 },
    { id: 'timeline', label: 'Career Timeline', icon: GitBranch },
    { id: 'contacts', label: 'Contacts', icon: Users },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'achievements', label: 'Achievements & Awards', icon: Star },
    { id: 'testimonials', label: 'Testimonials', icon: MessageSquare },
    { id: 'vault', label: 'Document Vault', icon: FolderLock },
    { id: 'notepad', label: 'Note Pad', icon: StickyNote }
  ];

  const getActiveTabBreadcrumb = () => {
    const matched = sidebarItems.find(item => item.id === activeTab);
    return matched ? matched.label : 'Home Page';
  };

  return (
    <div className="min-h-screen bg-[#08090d] text-gray-300 flex flex-col md:flex-row font-sans relative antialiased" id="nexus-crm-shell">
      
      {/* 1. CYBER NAVIGATION SIDEBAR (Desktop) */}
      <aside className="w-64 bg-[#0a0b0d] border-r border-slate-900 flex-col hidden md:flex shrink-0 z-10 select-none">
        
        {/* Sidebar Brand header */}
        <div className="p-6 border-b border-slate-900/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-emerald-500/10 text-emerald-400 p-2 rounded-xl border border-emerald-500/25">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h1 className="font-sans font-bold text-sm tracking-tight text-white leading-none">NexusCRM</h1>
              <span className="text-[9px] text-gray-500 font-mono tracking-wider font-semibold">Intelligence Hub</span>
            </div>
          </div>
        </div>

        {/* Navigation Sidebar links */}
        <nav className="flex-1 px-4 py-6 overflow-y-auto space-y-1 custom-scrollbar text-xs">
          {sidebarItems.map(nav => {
            const Icon = nav.icon;
            const isActive = activeTab === nav.id;

            return (
              <button
                key={nav.id}
                id={`sidebar-nav-${nav.id}`}
                onClick={() => setActiveTab(nav.id)}
                className={`w-full flex items-center gap-3.5 py-2.5 px-3 rounded-xl transition duration-150 font-semibold cursor-pointer ${
                  isActive 
                    ? 'bg-slate-900/80 text-emerald-400 font-bold border border-slate-800/60' 
                    : 'text-gray-400 hover:text-white hover:bg-slate-900/20'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-gray-500'}`} />
                <span className="truncate">{nav.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Sidebar Settings Option at absolute bottom */}
        <div className="p-4 border-t border-slate-900/80 bg-slate-950/20 space-y-1.5">
          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3.5 py-2.5 px-3 rounded-xl text-xs font-semibold cursor-pointer transition ${
              activeTab === 'settings' 
                ? 'bg-slate-900/80 text-emerald-400 font-bold border border-slate-800/60' 
                : 'text-gray-400 hover:text-white hover:bg-slate-900/20'
            }`}
          >
            <Settings className="w-4 h-4 text-gray-500 shrink-0" />
            <span>Settings</span>
          </button>

          <button
            onClick={() => {
              setConfirmDialog({
                title: "Confirm Sign Out",
                message: "Are you sure you want to log out of NexusCRM? Your details will be securely preserved.",
                onConfirm: () => {
                  handleUserLogout();
                  setConfirmDialog(null);
                  triggerToast("Logged out successfully.");
                }
              });
            }}
            className="w-full flex items-center gap-3.5 py-2.5 px-3 rounded-xl text-xs font-semibold text-rose-450 hover:text-rose-450 hover:bg-rose-950/20 cursor-pointer transition"
          >
            <LogOut className="w-4 h-4 text-gray-500 shrink-0" />
            <span>Logout</span>
          </button>
        </div>

      </aside>

      {/* 2. MOBILE TOP HEADER */}
      <header className="md:hidden bg-[#0a0b0d] text-white border-b border-slate-900 px-4 py-3 flex items-center justify-between z-30 shrink-0 select-none">
        <div className="flex items-center gap-2">
          <div className="bg-emerald-500/10 text-emerald-400 p-1 rounded-lg border border-emerald-500/20">
            <Sparkles className="w-4.5 h-4.5 animate-pulse" />
          </div>
          <div>
            <h1 className="font-sans font-bold text-xs tracking-tight text-white leading-none">NexusCRM</h1>
            <span className="text-[8px] text-gray-500 font-mono tracking-wider font-semibold">Intelligence Hub</span>
          </div>
        </div>

        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-1.5 rounded-lg hover:bg-slate-900 border border-slate-850/80 text-gray-300 transition shrink-0"
        >
          {isMobileMenuOpen ? (
            <X className="w-5 h-5 text-white" />
          ) : (
            <Menu className="w-5 h-5" />
          )}
        </button>
      </header>

      {/* MOBILE EXPANDED MENU DRAWER */}
      {isMobileMenuOpen && (
        <div className="fixed inset-x-0 top-[52px] bg-[#0a0b0d] border-b border-slate-900 z-20 flex flex-col p-4 max-h-[80vh] overflow-y-auto space-y-1.5 shadow-2xl md:hidden">
          {sidebarItems.map(nav => {
            const Icon = nav.icon;
            const isActive = activeTab === nav.id;

            return (
              <button
                key={nav.id}
                onClick={() => {
                  setActiveTab(nav.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 py-2 px-3 rounded-lg transition text-xs font-semibold cursor-pointer ${
                  isActive 
                    ? 'bg-slate-900 text-emerald-400 font-bold' 
                    : 'text-gray-400 hover:text-white hover:bg-slate-900/20'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{nav.label}</span>
              </button>
            );
          })}
          
          <div className="border-t border-slate-900 pt-3 mt-2 space-y-1">
            <button
              onClick={() => {
                setActiveTab('settings');
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-3 py-2 px-3 rounded-lg text-xs font-semibold text-gray-400 hover:text-white hover:bg-slate-900/20 cursor-pointer"
            >
              <Settings className="w-4 h-4 shrink-0" />
              <span>Settings</span>
            </button>
            <button
              onClick={() => {
                setConfirmDialog({
                  title: "Confirm Sign Out",
                  message: "Are you sure you want to log out? Your details will be safely preserved.",
                  onConfirm: () => {
                    handleUserLogout();
                    setIsMobileMenuOpen(false);
                    setConfirmDialog(null);
                    triggerToast("Logged out successfully.");
                  }
                });
              }}
              className="w-full flex items-center gap-3 py-2 px-3 rounded-lg text-xs font-semibold text-rose-450 hover:text-rose-400 hover:bg-rose-950/20 cursor-pointer"
            >
              <LogOut className="w-4 h-4 shrink-0" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. MAIN PANE CONTENT LAYER */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#08090d]">
        
        {/* Navigation Breadcrumbs & Top details header (exactly matches user profile section in screenshot) */}
        <header className="bg-[#0a0b0d] border-b border-slate-900 hidden md:flex items-center justify-between px-8 py-3.5 shadow-sm select-none z-10">
          <div className="flex items-center gap-2">
            <span className="text-gray-500 font-mono text-xs">Breadcrumb:</span>
            <div className="flex items-center gap-1.5 text-xs font-bold text-white uppercase tracking-wide">
              <span>🏠</span>
              <span>Home Page</span>
              <span className="text-gray-650 font-normal">/</span>
              <span className="text-emerald-400">{getActiveTabBreadcrumb()}</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold text-gray-400 font-sans">
            <button
              onClick={() => {
                const shareUrl = getFullShareUrl();
                navigator.clipboard.writeText(shareUrl);
                triggerToast("Public profile link copied!");
              }}
              className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 text-gray-300 hover:text-white transition py-1 px-3 rounded-xl text-[10px] font-semibold cursor-pointer active:scale-95"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>Copy Public Link</span>
            </button>

            <div className="flex items-center gap-1 bg-emerald-500/5 text-emerald-400 border border-emerald-500/10 px-2.5 py-0.5 rounded-full text-[10px] font-bold">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse mr-0.5" />
              Operational cloud synced
            </div>
            
            {/* User profile detail block as seen in top right of screenshot */}
            <div className="flex items-center gap-2.5 border-l border-slate-900 pl-4">
              <div className="text-right max-w-[150px]">
                <p className="font-bold text-white text-[11px] truncate leading-none" title={profile.name || `${currentUser?.firstName || ''} ${currentUser?.lastName || ''}`.trim() || currentUser?.email || 'User'}>
                  {profile.name || `${currentUser?.firstName || ''} ${currentUser?.lastName || ''}`.trim() || currentUser?.email?.split('@')[0] || 'User'}
                </p>
                <p className="text-[9px] text-gray-400 font-mono truncate mt-0.5 font-medium max-w-[135px]" title={currentUser?.email || profile.email || 'user@example.com'}>
                  {currentUser?.email || profile.email || 'user@example.com'}
                </p>
              </div>
              <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 font-bold flex items-center justify-center text-emerald-400 select-none shrink-0 text-xs">
                {(() => {
                  const currentName = profile.name || `${currentUser?.firstName || ''} ${currentUser?.lastName || ''}`.trim();
                  if (currentName) {
                    const parts = currentName.trim().split(/\s+/);
                    if (parts.length >= 2) {
                      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
                    }
                    return currentName.slice(0, 2).toUpperCase();
                  }
                  if (currentUser?.email) {
                    return currentUser.email.slice(0, 2).toUpperCase();
                  }
                  return 'US';
                })()}
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic State tab routing area */}
        <div className="p-4 sm:p-6 md:p-8 flex-1 max-w-6xl w-full mx-auto overflow-y-auto">
          {activeTab === 'overview' && (
            <OverviewTab 
              profile={profile}
              skills={skills}
              experience={experience}
              certifications={certifications}
              contacts={contacts}
              currentJob={currentJob}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileTab 
              profile={profile}
              onUpdateProfile={setProfile}
              shareUrl={getFullShareUrl()}
            />
          )}

          {activeTab === 'skills' && (
            <SkillsTab 
              skills={skills}
              onAddSkill={handleAddSkill}
              onUpdateSkill={handleUpdateSkill}
              onDeleteSkill={handleDeleteSkill}
            />
          )}

          {activeTab === 'education' && (
            <EducationTab 
              education={education}
              onAddEducation={handleAddEdu}
              onDeleteEducation={handleDeleteEdu}
              onUpdateEducation={handleUpdateEdu}
            />
          )}

          {activeTab === 'certifications' && (
            <CertificationsTab 
              certifications={certifications}
              onAddCertification={handleAddCert}
              onDeleteCertification={handleDeleteCert}
              onUpdateCertification={handleUpdateCert}
            />
          )}

          {activeTab === 'experience' && (
            <ExperienceTab 
              experience={experience}
              onAddExperience={handleAddExp}
              onDeleteExperience={handleDeleteExp}
            />
          )}

          {activeTab === 'current-job' && (
            <CurrentJobTab 
              currentJob={currentJob}
              onUpdateCurrentJob={setCurrentJob}
            />
          )}

          {activeTab === 'projects' && (
            <ProjectsTab 
              projects={projects}
              products={products}
              others={others}
              onAddProject={handleAddProj}
              onDeleteProject={handleDeleteProj}
              onUpdateProject={handleUpdateProj}
            />
          )}

          {activeTab === 'resume' && (
            <ResumeTab 
              profile={profile}
              skills={skills}
              education={education}
              certifications={certifications}
              experience={experience}
              links={resumeLinks}
              onAddLink={handleAddResumeLink}
              onDeleteLink={handleDeleteResumeLink}
              onUpdateLink={handleUpdateResumeLink}
              resumes={resumes}
              onUpdateResumes={setResumes}
            />
          )}

          {activeTab === 'portfolios' && (
            <PortfoliosTab 
              links={links}
              onAddLink={handleAddLink}
              onDeleteLink={handleDeleteLink}
              onUpdateLink={handleUpdateLink}
            />
          )}

          {activeTab === 'timeline' && (
            <TimelineTab 
              milestones={milestones}
              onAddMilestone={handleAddMilestone}
              onDeleteMilestone={handleDeleteMilestone}
              experience={experience}
              currentJob={currentJob}
            />
          )}

          {activeTab === 'contacts' && (
            <ContactsTab 
              contacts={contacts}
              onAddContact={handleAddContact}
              onDeleteContact={handleDeleteContact}
              onUpdateContact={handleUpdateContact}
              onAddInteraction={handleAddInteraction}
            />
          )}

          {activeTab === 'calendar' && (
            <CalendarTab 
              events={calendarEvents}
              onAddEvent={handleAddCalendarEvent}
              onUpdateEvent={handleUpdateCalendarEvent}
              onDeleteEvent={handleDeleteCalendarEvent}
            />
          )}

          {activeTab === 'achievements' && (
            <AchievementsTab 
              achievements={achievements}
              onAddAchievement={handleAddAchievement}
              onDeleteAchievement={handleDeleteAchievement}
            />
          )}

          {activeTab === 'testimonials' && (
            <TestimonialsTab 
              testimonials={testimonials}
              onAddTestimonial={handleAddTestimonial}
              onDeleteTestimonial={handleDeleteTestimonial}
            />
          )}

          {activeTab === 'vault' && (
            <DocumentVaultTab 
              documents={documents}
              onAddDocument={handleAddDocument}
              onDeleteDocument={handleDeleteDocument}
            />
          )}

          {activeTab === 'notepad' && (
            <NotepadTab 
              currentUserEmail={currentUser?.email}
              triggerToast={triggerToast}
              notes={notes}
              onUpdateNotes={setNotes}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsTab 
              onRestoreDefaults={handleRestoreDefaults}
              onWipeData={handleWipeData}
            />
          )}
        </div>

      </main>

      {/* 4. NOTIFICATION MARGIN TOAST */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white py-3 px-5 rounded-2xl shadow-xl flex items-center justify-between gap-4 max-w-sm font-sans select-none animate-fade-in">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 bg-emerald-400 rounded-full shrink-0 animate-pulse" />
            <p className="text-xs font-semibold leading-normal">{toastMessage}</p>
          </div>
          <button 
            onClick={() => setToastMessage(null)}
            className="text-gray-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* CUSTOM CONFIRMATION DIALOG MODAL (Iframe Safe) */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in" id="nexus-confirm-overlay">
          <div className="bg-[#0e1014] border border-slate-850 max-w-md w-full rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white tracking-tight">{confirmDialog.title}</h3>
            <p className="text-xs text-gray-400 leading-relaxed font-sans">{confirmDialog.message}</p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 hover:bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold text-gray-300 transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-500/10"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
