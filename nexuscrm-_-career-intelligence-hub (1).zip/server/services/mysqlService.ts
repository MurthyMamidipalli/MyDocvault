import mysql, { Pool } from "mysql2/promise";
import { localStore } from "./localStore";

export interface CompleteUserData {
  profile?: any;
  education?: any[];
  experience?: any[];
  skills?: any[];
  projects?: any[];
  products?: any[];
  others?: any[];
  certifications?: any[];
  documents?: any[];
  resumes?: any[];
  notes?: any[];
  calendarEvents?: any[];
  contacts?: any[];
  currentJob?: any;
  links?: any[];
  resumeLinks?: any[];
  milestones?: any[];
  achievements?: any[];
  testimonials?: any[];
}

class MySQLService {
  private pool: Pool | null = null;
  private isConfigured = false;
  private tablesInspected = false;
  private tableColumns: Record<string, Set<string>> = {};

  constructor() {
    this.initPool();
  }

  private initPool() {
    const connectionUrl = process.env.MYSQL_URL || process.env.DATABASE_URL;
    const host = process.env.MYSQL_HOST || process.env.DB_HOST;
    const user = process.env.MYSQL_USER || process.env.DB_USER;
    const password = process.env.MYSQL_PASSWORD || process.env.DB_PASSWORD;
    const database = process.env.MYSQL_DATABASE || process.env.DB_NAME;
    const port = Number(process.env.MYSQL_PORT || process.env.DB_PORT || 3306);

    try {
      if (connectionUrl) {
        console.log("[MySQL Service] Initializing MySQL pool from connection URL...");
        this.pool = mysql.createPool({
          uri: connectionUrl,
          waitForConnections: true,
          connectionLimit: 10,
          queueLimit: 0,
        });
        this.isConfigured = true;
      } else if (host && user && database) {
        console.log(`[MySQL Service] Initializing MySQL pool for ${user}@${host}:${port}/${database}...`);
        this.pool = mysql.createPool({
          host,
          user,
          password: password || "",
          database,
          port,
          waitForConnections: true,
          connectionLimit: 10,
          queueLimit: 0,
        });
        this.isConfigured = true;
      } else {
        console.log("[MySQL Service] MySQL credentials not detected in environment. Using durable local store engine.");
        this.isConfigured = false;
      }
    } catch (e: any) {
      console.warn("[MySQL Service] Failed to initialize MySQL pool, falling back to local store:", e.message);
      this.isConfigured = false;
    }
  }

  public isConnected(): boolean {
    return this.isConfigured && this.pool !== null;
  }

  private async inspectTable(tableName: string): Promise<Set<string>> {
    if (this.tableColumns[tableName]) {
      return this.tableColumns[tableName];
    }
    const cols = new Set<string>();
    if (!this.pool) return cols;

    try {
      const [rows]: any = await this.pool.query(`DESCRIBE \`${tableName}\``);
      if (Array.isArray(rows)) {
        for (const row of rows) {
          if (row.Field) cols.add(row.Field.toLowerCase());
        }
      }
      this.tableColumns[tableName] = cols;
    } catch (e: any) {
      // Table might not exist or error
    }
    return cols;
  }

  /**
   * Save complete user data payload to MySQL or local store.
   */
  async saveUserData(email: string, rawData: CompleteUserData): Promise<CompleteUserData> {
    const cleanEmail = email.toLowerCase().trim();
    const projects = Array.isArray(rawData.projects) ? rawData.projects : [];
    const products = Array.isArray(rawData.products) ? rawData.products : [];
    const others = Array.isArray(rawData.others) ? rawData.others : [];

    console.log(`[MySQL Service] Saving workspace data for ${cleanEmail}:`);
    console.log(`[MySQL Service] Projects count: ${projects.length}`);
    console.log(`[MySQL Service] Products count: ${products.length}`);
    console.log(`[MySQL Service] Others/documents count: ${others.length}`);

    // Always keep local disk store up to date as reliable mirror
    localStore.saveUserData(cleanEmail, {
      ...rawData,
      projects,
      products,
      others
    });

    if (!this.isConnected()) {
      console.log(`[MySQL Service] Saved ${projects.length} projects and ${products.length} products to local store cache for ${cleanEmail}.`);
      return rawData;
    }

    try {
      // 1. Save or update user in 'users' table
      const [userRows]: any = await this.pool!.query(
        "SELECT email FROM users WHERE email = ? LIMIT 1",
        [cleanEmail]
      );
      if (!Array.isArray(userRows) || userRows.length === 0) {
        await this.pool!.query(
          "INSERT INTO users (id, email, first_name, last_name, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())",
          [
            `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            cleanEmail,
            rawData.profile?.firstName || "",
            rawData.profile?.lastName || ""
          ]
        );
      }

      // Helper to save table with JSON column 'data'
      const saveJsonTable = async (tableName: string, payload: any) => {
        const payloadString = JSON.stringify(payload);
        const [existing]: any = await this.pool!.query(
          `SELECT id FROM \`${tableName}\` WHERE user_email = ? LIMIT 1`,
          [cleanEmail]
        );

        if (Array.isArray(existing) && existing.length > 0) {
          await this.pool!.query(
            `UPDATE \`${tableName}\` SET data = ?, updated_at = NOW() WHERE id = ?`,
            [payloadString, existing[0].id]
          );
        } else {
          const newId = `doc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          await this.pool!.query(
            `INSERT INTO \`${tableName}\` (id, user_email, data, updated_at) VALUES (?, ?, ?, NOW())`,
            [newId, cleanEmail, payloadString]
          );
        }
      };

      // 2. Save Projects (support both column schemas: JSON 'data' or separate rows)
      const projectCols = await this.inspectTable("projects");
      if (projectCols.has("data") || projectCols.size === 0) {
        // Table uses JSON 'data' column for the complete projects array
        await saveJsonTable("projects", projects);
        console.log(`[MySQL Service] Saved array of ${projects.length} projects into 'projects' (data JSON column) for ${cleanEmail}`);
      } else {
        // Table uses individual rows per project (id is primary key, user_email is foreign key)
        // Check if there is an accidental UNIQUE constraint on user_email that would overwrite rows
        try {
          const [indexRows]: any = await this.pool!.query(
            "SHOW INDEX FROM `projects` WHERE Column_name = 'user_email' AND Non_unique = 0 AND Key_name != 'PRIMARY'"
          );
          if (Array.isArray(indexRows) && indexRows.length > 0) {
            for (const idx of indexRows) {
              console.log(`[MySQL Fix] Removing UNIQUE constraint '${idx.Key_name}' on user_email in projects table to support multiple projects...`);
              await this.pool!.query(`ALTER TABLE \`projects\` DROP INDEX \`${idx.Key_name}\``);
            }
          }
        } catch (e: any) {
          // Ignore index check error if user permissions don't allow ALTER
        }

        // Clean up any projects for this user that are not in current list
        const currentIds = projects.map(p => p.id).filter(Boolean);
        if (currentIds.length > 0) {
          const placeholders = currentIds.map(() => '?').join(',');
          await this.pool!.query(
            `DELETE FROM \`projects\` WHERE user_email = ? AND id NOT IN (${placeholders})`,
            [cleanEmail, ...currentIds]
          );
        } else {
          await this.pool!.query("DELETE FROM `projects` WHERE user_email = ?", [cleanEmail]);
        }

        for (const pr of projects) {
          const prId = pr.id || `proj_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          await this.pool!.query(
            `INSERT INTO \`projects\` 
              (id, user_email, name, category, type, date, description, tech_stack, live_url, github_url, cover_url, pdf_url, pdf_name, percentage, is_public, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
              name = VALUES(name),
              category = VALUES(category),
              type = VALUES(type),
              date = VALUES(date),
              description = VALUES(description),
              tech_stack = VALUES(tech_stack),
              live_url = VALUES(live_url),
              github_url = VALUES(github_url),
              cover_url = VALUES(cover_url),
              pdf_url = VALUES(pdf_url),
              pdf_name = VALUES(pdf_name),
              percentage = VALUES(percentage),
              is_public = VALUES(is_public),
              updated_at = NOW()`,
            [
              prId,
              cleanEmail,
              pr.name || "",
              pr.category || "utilities",
              pr.type || "project",
              pr.date || "",
              pr.description || "",
              JSON.stringify(pr.techStack || []),
              pr.liveUrl || "",
              pr.githubUrl || "",
              pr.coverUrl || "",
              pr.pdfUrl || "",
              pr.pdfName || "",
              pr.percentage || "",
              pr.isPublic !== false
            ]
          );
        }
        console.log(`[MySQL Service] Upserted ${projects.length} individual project records for user_email: ${cleanEmail}`);
      }

      // 3. Save Products (support both column schemas: JSON 'data' or separate rows)
      const productCols = await this.inspectTable("products");
      if (productCols.has("data") || productCols.size === 0) {
        // Table uses JSON 'data' column for the complete products array
        await saveJsonTable("products", products);
        console.log(`[MySQL Service] Saved array of ${products.length} products into 'products' (data JSON column) for ${cleanEmail}`);
      } else {
        // Check if there is an accidental UNIQUE constraint on user_email in products table
        try {
          const [indexRows]: any = await this.pool!.query(
            "SHOW INDEX FROM `products` WHERE Column_name = 'user_email' AND Non_unique = 0 AND Key_name != 'PRIMARY'"
          );
          if (Array.isArray(indexRows) && indexRows.length > 0) {
            for (const idx of indexRows) {
              console.log(`[MySQL Fix] Removing UNIQUE constraint '${idx.Key_name}' on user_email in products table to support multiple products...`);
              await this.pool!.query(`ALTER TABLE \`products\` DROP INDEX \`${idx.Key_name}\``);
            }
          }
        } catch (e: any) {
          // Ignore index check error if user permissions don't allow ALTER
        }

        // Clean up any products for this user that are not in current list
        const currentProdIds = products.map(p => p.id).filter(Boolean);
        if (currentProdIds.length > 0) {
          const placeholders = currentProdIds.map(() => '?').join(',');
          await this.pool!.query(
            `DELETE FROM \`products\` WHERE user_email = ? AND id NOT IN (${placeholders})`,
            [cleanEmail, ...currentProdIds]
          );
        } else {
          await this.pool!.query("DELETE FROM `products` WHERE user_email = ?", [cleanEmail]);
        }

        for (const prod of products) {
          const prodId = prod.id || `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          await this.pool!.query(
            `INSERT INTO \`products\` 
              (id, user_email, name, category, type, date, description, tech_stack, live_url, github_url, cover_url, pdf_url, pdf_name, percentage, is_public, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
              name = VALUES(name),
              category = VALUES(category),
              type = VALUES(type),
              date = VALUES(date),
              description = VALUES(description),
              tech_stack = VALUES(tech_stack),
              live_url = VALUES(live_url),
              github_url = VALUES(github_url),
              cover_url = VALUES(cover_url),
              pdf_url = VALUES(pdf_url),
              pdf_name = VALUES(pdf_name),
              percentage = VALUES(percentage),
              is_public = VALUES(is_public),
              updated_at = NOW()`,
            [
              prodId,
              cleanEmail,
              prod.name || "",
              prod.category || "utilities",
              prod.type || "product",
              prod.date || "",
              prod.description || "",
              JSON.stringify(prod.techStack || []),
              prod.liveUrl || "",
              prod.githubUrl || "",
              prod.coverUrl || "",
              prod.pdfUrl || "",
              prod.pdfName || "",
              prod.percentage || "",
              prod.isPublic !== false
            ]
          );
        }
        console.log(`[MySQL Service] Upserted ${products.length} individual product records for user_email: ${cleanEmail}`);
      }

      // 4. Save other workspace tables
      const otherTables = [
        { name: "profiles", payload: rawData.profile || {} },
        { name: "education", payload: rawData.education || [] },
        { name: "experience", payload: rawData.experience || [] },
        { name: "skills", payload: rawData.skills || [] },
        { name: "certifications", payload: rawData.certifications || [] },
        { name: "documents", payload: rawData.documents || [] },
        { name: "resumes", payload: rawData.resumes || [] },
        { name: "notes", payload: rawData.notes || [] },
        { name: "calendar_events", payload: rawData.calendarEvents || [] },
        { name: "contacts", payload: rawData.contacts || [] },
        { name: "settings", payload: rawData.currentJob || {} },
      ];

      for (const t of otherTables) {
        try {
          await saveJsonTable(t.name, t.payload);
        } catch (tableErr: any) {
          console.warn(`[MySQL Service] Non-critical warning saving table '${t.name}':`, tableErr.message);
        }
      }

      console.log("[PROJECT DEBUG] saved projects COUNT:", (rawData.projects || []).length);
      console.log(`[MySQL Service] Successfully completed saving ${projects.length} projects and ${products.length} products to MySQL for ${cleanEmail}!`);
    } catch (dbError: any) {
      console.error("[MySQL Service] Error executing MySQL query, local store active as fallback:", dbError.message);
    }

    return rawData;
  }

  /**
   * Retrieve complete user data payload from MySQL or local store.
   */
  async getUserData(email: string): Promise<CompleteUserData> {
    const cleanEmail = email.toLowerCase().trim();

    // Default to localStore baseline
    const localData = localStore.getUserData(cleanEmail);

    if (!this.isConnected()) {
      console.log(`[MySQL Service] Retrieved ${localData.projects?.length || 0} projects and ${localData.products?.length || 0} products from local store for ${cleanEmail}.`);
      return localData;
    }

    try {
      console.log(`[MySQL Service] Fetching workspace data from MySQL for: ${cleanEmail}`);

      // Helper to fetch JSON table
      const fetchJsonTable = async (tableName: string) => {
        try {
          const [rows]: any = await this.pool!.query(
            `SELECT data FROM \`${tableName}\` WHERE user_email = ? LIMIT 1`,
            [cleanEmail]
          );
          if (Array.isArray(rows) && rows.length > 0 && rows[0].data) {
            const raw = rows[0].data;
            return typeof raw === "string" ? JSON.parse(raw) : raw;
          }
        } catch (e: any) {
          // Table or column might differ
        }
        return null;
      };

      // 1. Fetch Projects
      let loadedProjects: any[] | null = null;
      const projectCols = await this.inspectTable("projects");
      if (projectCols.has("data") || projectCols.size === 0) {
        loadedProjects = await fetchJsonTable("projects");
      } else {
        // Individual rows - check column existence before adding order clause
        const orderBy = projectCols.has("date") ? "ORDER BY date DESC" : "";
        const [rows]: any = await this.pool!.query(
          `SELECT * FROM \`projects\` WHERE user_email = ? ${orderBy}`.trim(),
          [cleanEmail]
        );
        if (Array.isArray(rows)) {
          loadedProjects = rows.map((r: any) => ({
            id: r.id,
            name: r.name,
            category: r.category,
            type: r.type || "project",
            date: r.date,
            description: r.description,
            techStack: typeof r.tech_stack === "string" ? JSON.parse(r.tech_stack || "[]") : (r.tech_stack || []),
            liveUrl: r.live_url,
            githubUrl: r.github_url,
            coverUrl: r.cover_url,
            pdfUrl: r.pdf_url,
            pdfName: r.pdf_name,
            percentage: r.percentage,
            isPublic: r.is_public !== 0 && r.is_public !== false
          }));
        }
      }

      // 2. Fetch Products
      let loadedProducts: any[] | null = null;
      const productCols = await this.inspectTable("products");
      if (productCols.has("data") || productCols.size === 0) {
        loadedProducts = await fetchJsonTable("products");
      } else {
        // Individual rows - check column existence before adding order clause
        const prodOrderBy = productCols.has("date") ? "ORDER BY date DESC" : "";
        const [rows]: any = await this.pool!.query(
          `SELECT * FROM \`products\` WHERE user_email = ? ${prodOrderBy}`.trim(),
          [cleanEmail]
        );
        if (Array.isArray(rows)) {
          loadedProducts = rows.map((r: any) => ({
            id: r.id,
            name: r.name,
            category: r.category,
            type: r.type || "product",
            date: r.date,
            description: r.description,
            techStack: typeof r.tech_stack === "string" ? JSON.parse(r.tech_stack || "[]") : (r.tech_stack || []),
            liveUrl: r.live_url,
            githubUrl: r.github_url,
            coverUrl: r.cover_url,
            pdfUrl: r.pdf_url,
            pdfName: r.pdf_name,
            percentage: r.percentage,
            isPublic: r.is_public !== 0 && r.is_public !== false
          }));
        }
      }

      const finalProjects = Array.isArray(loadedProjects) ? loadedProjects : (localData.projects || []);
      const finalProducts = Array.isArray(loadedProducts) ? loadedProducts : (localData.products || []);

      console.log("[PROJECT DEBUG] retrieved projects COUNT:", finalProjects.length);
      console.log(`[MySQL Service] Retrieved ${finalProjects.length} projects and ${finalProducts.length} products for ${cleanEmail}.`);

      const completeData: CompleteUserData = {
        profile: (await fetchJsonTable("profiles")) || localData.profile || {},
        education: (await fetchJsonTable("education")) || localData.education || [],
        experience: (await fetchJsonTable("experience")) || localData.experience || [],
        skills: (await fetchJsonTable("skills")) || localData.skills || [],
        projects: finalProjects,
        products: finalProducts,
        others: localData.others || [],
        certifications: (await fetchJsonTable("certifications")) || localData.certifications || [],
        documents: (await fetchJsonTable("documents")) || localData.documents || [],
        resumes: (await fetchJsonTable("resumes")) || localData.resumes || [],
        notes: (await fetchJsonTable("notes")) || localData.notes || [],
        calendarEvents: (await fetchJsonTable("calendar_events")) || localData.calendarEvents || [],
        contacts: (await fetchJsonTable("contacts")) || localData.contacts || [],
        currentJob: (await fetchJsonTable("settings")) || localData.currentJob || {},
      };

      // Keep local store in sync with MySQL query result
      localStore.saveUserData(cleanEmail, completeData);

      return completeData;
    } catch (e: any) {
      console.error("[MySQL Service] Error fetching from MySQL, returning local store copy:", e.message);
      return localData;
    }
  }

  async getAllUsers(): Promise<any[]> {
    if (!this.isConnected()) {
      return localStore.getAllUsers();
    }
    try {
      const [rows]: any = await this.pool!.query(
        "SELECT id, email, first_name, last_name, password, is_mail_only FROM users"
      );
      if (Array.isArray(rows) && rows.length > 0) {
        return rows;
      }
    } catch (e: any) {
      console.warn("[MySQL Service] Error querying users table:", e.message);
    }
    return localStore.getAllUsers();
  }

  async createUser(email: string, passwordHash: string, firstName?: string, lastName?: string, isMailOnly = false): Promise<any> {
    const cleanEmail = email.toLowerCase().trim();
    localStore.createUser(cleanEmail, passwordHash, firstName, lastName, isMailOnly);

    if (this.isConnected()) {
      try {
        const id = `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        await this.pool!.query(
          "INSERT INTO users (id, email, password, first_name, last_name, is_mail_only, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW()) ON DUPLICATE KEY UPDATE first_name = VALUES(first_name), last_name = VALUES(last_name), updated_at = NOW()",
          [id, cleanEmail, passwordHash || "", firstName || "", lastName || "", isMailOnly]
        );
      } catch (e: any) {
        console.warn("[MySQL Service] Error inserting into users table:", e.message);
      }
    }

    return {
      $id: cleanEmail,
      email: cleanEmail,
      first_name: firstName,
      last_name: lastName,
      is_mail_only: isMailOnly
    };
  }
}

export const mysqlService = new MySQLService();
